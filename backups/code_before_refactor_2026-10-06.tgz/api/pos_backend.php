<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($base_path)) {
    $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
    $base_path = (basename($scriptDir) === 'pages') ? '../' : '../../';
}
require_once __DIR__ . '/../config/db.php';

// Check authorization
if (empty($_SESSION['user_id'])) {
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) || $_SERVER['REQUEST_METHOD'] === 'POST') {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'ເຊດຊັນໝົດອາຍຸ! ກະລຸນາເຂົ້າສູ່ລະບົບໃໝ່']);
        exit();
    }
    echo "<script>window.top.location.href = '../index.php';</script>";
    exit();
}

$vat_rate = floatval(getSetting($pdo, 'vat_rate', '0'));

// Fetch Company/Store info for the branch making this sale — shared name/address/phone from
// the main branch, logo specific to this branch.
$company = getCompanyInfoForBranch($pdo, getPosStoreId());

// Helper function to get client IP
function getClientIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    } else {
        return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    }
}

// Live Stock Polling Handler
if (isset($_GET['action']) && $_GET['action'] === 'get_live_stocks') {
    header('Content-Type: application/json');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');
    $liveStoreId = getPosStoreId();
    $stmt = $pdo->prepare("SELECT product_id, qty FROM products WHERE store_id = ?");
    $stmt->execute([$liveStoreId]);
    $stocks = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['success' => true, 'stocks' => $stocks]);
    exit();
}

// LAN kitchen ticket: the POS draws the ticket as a PNG (the browser shapes the Lao text,
// which printer fonts can't) and this relays it to the category's network printer.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'print_lan_ticket') {
    header('Content-Type: application/json');
    // Wrapped end-to-end: any Throwable anywhere in this block (including one the inner
    // try/catches below don't happen to cover) still comes back as JSON with file:line instead
    // of a bare 500 — this block runs on hosts we don't have shell/log access to, so the
    // response body has to be the diagnostic, not the server's own error log.
    try {
    require_once __DIR__ . '/lan_printer.php';
    // Don't hold the session lock while waiting on the printer socket.
    session_write_close();

    $printerId = intval($_POST['printer_id'] ?? 0);
    $image     = (string)($_POST['image'] ?? '');
    $pngPrefix = 'data:image/png;base64,';
    if ($printerId <= 0 || strpos($image, $pngPrefix) !== 0 || strlen($image) > 4000000) {
        echo json_encode(['success' => false, 'message' => t('pos.lan_print_bad_request', 'ຂໍ້ມູນການພິມບໍ່ຖືກຕ້ອງ')], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $prStmt = $pdo->prepare("SELECT * FROM tbl_printer WHERE id = ? AND status = 1 LIMIT 1");
    $prStmt->execute([$printerId]);
    $printer = $prStmt->fetch();
    $isUsb = $printer && ($printer['type'] ?? '') === 'usb';
    if (!$printer || (($printer['type'] ?? '') !== 'ip' && !$isUsb)) {
        echo json_encode(['success' => false, 'message' => t('pos.lan_print_not_lan', 'ເຄື່ອງພິມນີ້ປິດໃຊ້ງານ ຫຼື ບໍ່ໄດ້ຕັ້ງເປັນ Network LAN')], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $addr = $isUsb ? null : lanPrinterAddress($printer['ip_address'] ?? '');
    if (!$isUsb && $addr === null) {
        echo json_encode(['success' => false, 'message' => t('pos.lan_print_bad_ip', 'IP Address ຂອງເຄື່ອງພິມບໍ່ຖືກຕ້ອງ')], JSON_UNESCAPED_UNICODE);
        exit();
    }

    // GD renders the PNG-to-ESC/POS raster below — on some shared hosting it's disabled, which
    // would otherwise fatal into a blank 500 (no JSON) instead of a message the cashier can see.
    if (!extension_loaded('gd')) {
        echo json_encode(['success' => false, 'message' => t('pos.lan_print_no_gd', 'ເຊີບເວີບໍ່ໄດ້ເປີດໃຊ້ GD extension — ພິມຜ່ານ LAN ບໍ່ໄດ້')], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $png = base64_decode(substr($image, strlen($pngPrefix)), true);
    try {
        $bytes = ($png !== false) ? escposRasterFromPng($png, lanPrinterDots($printer['paper_width'] ?? 80)) : null;
    } catch (Throwable $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if ($bytes === null) {
        echo json_encode(['success' => false, 'message' => t('pos.lan_print_bad_request', 'ຂໍ້ມູນການພິມບໍ່ຖືກຕ້ອງ')], JSON_UNESCAPED_UNICODE);
        exit();
    }

    // USB printer on this PC: the very same bytes go to the Windows spooler as RAW data, so the
    // bill is identical to a LAN one (api/usb_printer.php). Always direct — never the agent queue.
    if ($isUsb) {
        require_once __DIR__ . '/usb_printer.php';
        $usbName = usbPrinterName($printer['ip_address'] ?? '');
        [$ok, $err] = $usbName === null ? [false, t('pos.usb_print_no_name', 'ບໍ່ໄດ້ໃສ່ຊື່ເຄື່ອງພິມ USB')] : usbPrinterSend($usbName, $bytes);
        echo json_encode([
            'success' => $ok,
            'message' => $ok ? '' : ($printer['name'] . ' (USB: ' . ($usbName ?? '') . ') — ' . $err),
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    // Off-site server (Settings > Printers > print_mode = agent): this box can't open a socket
    // to the shop's 192.168.x.x printer itself, so the finished ESC/POS bytes are parked in
    // print_jobs for tools/print-agent.php — which DOES sit on that LAN — to collect and send.
    if (getSetting($pdo, 'print_mode', 'direct') === 'agent') {
        try {
            $pdo->prepare("INSERT INTO print_jobs (printer_id, store_id, payload) VALUES (?, ?, ?)")
                ->execute([$printerId, getPosStoreId(), base64_encode($bytes)]);
            echo json_encode(['success' => true, 'queued' => true], JSON_UNESCAPED_UNICODE);
        } catch (Throwable $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
        }
        exit();
    }

    [$ok, $err] = lanPrinterSend($addr[0], $addr[1], $bytes);
    echo json_encode([
        'success' => $ok,
        'message' => $ok ? '' : ($printer['name'] . ' (' . $addr[0] . ':' . $addr[1] . ') — ' . $err),
    ], JSON_UNESCAPED_UNICODE);
    exit();
    } catch (Throwable $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage() . ' @ ' . basename($e->getFile()) . ':' . $e->getLine(),
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
}

// 1. AJAX handler for Checkout
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'checkout') {
    ob_start();
    header('Content-Type: application/json');
    $cart = json_decode($_POST['cart'] ?? '[]', true);
    $cash_received = floatval($_POST['cash_received'] ?? 0.00);
    $qr_received   = floatval($_POST['qr_received']   ?? 0.00);
    $payment_type  = $_POST['payment_type'] ?? 'ເງິນສົດ';
    $pay_mode      = $_POST['pay_mode']     ?? 'single';
    $discount_bill = floatval($_POST['discount_amount'] ?? 0.00);
    $customer_id   = !empty($_POST['customer_id']) ? strval($_POST['customer_id']) : '';
    $customer_name = !empty($_POST['customer_name']) ? trim($_POST['customer_name']) : 'ລູກຄ້າທົ່ວໄປ';
    $client_ip     = getClientIP();
    // Loyalty rewards the customer is exchanging points for on this bill — a list of
    // loyalty_rewards ids (an id repeats when the same reward is redeemed twice). Costs and
    // discount values are always re-read from the DB below, never taken from the client.
    $redeem_ids = json_decode($_POST['redemptions'] ?? '[]', true);
    $redeem_ids = is_array($redeem_ids) ? array_values(array_filter(array_map('intval', $redeem_ids))) : [];

    // Tender currency for this bill (chosen at checkout). Base data stays in KIP; these
    // just record what the customer handed over so the daily report can split by currency.
    $allowed_currencies = ['KIP', 'THB', 'USD', 'CNY'];
    $paid_currency = strtoupper(trim((string)($_POST['paid_currency'] ?? 'KIP')));
    if (!in_array($paid_currency, $allowed_currencies, true)) $paid_currency = 'KIP';
    $paid_rate = ($paid_currency === 'KIP') ? 1.0 : (float)($_POST['paid_rate'] ?? 0);
    if ($paid_rate <= 0) { $paid_currency = 'KIP'; $paid_rate = 1.0; }
    
    if (empty($cart)) {
        echo json_encode(['success' => false, 'message' => 'ກະຕ່າສິນຄ້າຫວ່າງເປົ່າ!']);
        exit();
    }

    // Idempotency guard: the exact same checkout (same cart + amounts + customer, same login
    // session) arriving again within a few seconds is a duplicate submission — a double-tap on
    // the submit button, a slow-network retry, or a stale browser tab that fired before a fix
    // landed — never a genuine second sale (a real repeat purchase is never byte-identical down
    // to the tendered amounts). Replay the first request's own response instead of creating a
    // second bill and decrementing stock twice. This is server-side and session-scoped, so it
    // still catches a duplicate even if the client-side re-entrancy guard in pos_checkout_js.php
    // was bypassed or hasn't loaded yet.
    $idemFp = md5(($_POST['cart'] ?? '') . '|' . $cash_received . '|' . $qr_received . '|' .
        $payment_type . '|' . $discount_bill . '|' . $customer_id . '|' . implode(',', $redeem_ids) . '|' . ($_SESSION['user_id'] ?? ''));
    if (
        isset($_SESSION['pos_last_checkout_fp'], $_SESSION['pos_last_checkout_time'], $_SESSION['pos_last_checkout_response']) &&
        $_SESSION['pos_last_checkout_fp'] === $idemFp &&
        (time() - $_SESSION['pos_last_checkout_time']) < 20
    ) {
        echo json_encode($_SESSION['pos_last_checkout_response']);
        exit();
    }

    try {
        $pdo->beginTransaction();
        
        $user_receive_name = $_SESSION['username'] ?? $_SESSION['fname'] ?? 'Admin';
        $sold_by_id        = intval($_SESSION['user_id'] ?? 1);
        
        // Calculate totals & Tax/VAT
        $subtotal = 0;
        $total_cost = 0;
        $total_qty = 0;
        
        foreach ($cart as $item) {
            $qty = floatval($item['quantity']);
            $price = floatval($item['unit_price']);
            $cost = floatval($item['cost_price']);
            $subtotal += ($qty * $price);
            $total_cost += ($qty * $cost);
            $total_qty += $qty;
        }
        
        $tax_type = !empty($company['tax_type']) ? $company['tax_type'] : 'none';
        $vat_percent = ($tax_type === 'none') ? 0.00 : floatval($company['vat_percent'] ?? 0);

        // ===== LOYALTY REDEMPTION: validate + price the rewards before any totals are fixed =====
        $points_redeemed = 0;
        $points_discount = 0.00;
        $redeem_notes    = [];
        if (!empty($redeem_ids)) {
            $redeemFail = function ($msg) use ($pdo) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                echo json_encode(['success' => false, 'message' => $msg]);
                exit();
            };
            if (getSetting($pdo, 'loyalty_enabled', '0') !== '1') {
                $redeemFail(t('pos.redeem_err_disabled', 'ລະບົບຄະແນນສະສົມຖືກປິດຢູ່ — ແລກຄະແນນບໍ່ໄດ້'));
            }
            if (intval($customer_id) <= 0) {
                $redeemFail(t('pos.redeem_err_no_customer', 'ກະລຸນາເລືອກລູກຄ້າກ່ອນແລກຄະແນນ'));
            }
            // Lock the customer's row so two tills can't spend the same points at once.
            $lockStmt = $pdo->prepare("SELECT points FROM customers WHERE customer_id = ? FOR UPDATE");
            $lockStmt->execute([intval($customer_id)]);
            $pointsAvailable = $lockStmt->fetchColumn();
            if ($pointsAvailable === false) {
                $redeemFail(t('pos.redeem_err_no_customer', 'ກະລຸນາເລືອກລູກຄ້າກ່ອນແລກຄະແນນ'));
            }

            $uniqIds = array_values(array_unique($redeem_ids));
            $rwStmt = $pdo->prepare("SELECT * FROM loyalty_rewards WHERE is_active = 1 AND id IN (" . implode(',', array_fill(0, count($uniqIds), '?')) . ")");
            $rwStmt->execute($uniqIds);
            $rewardsById = [];
            foreach ($rwStmt->fetchAll(PDO::FETCH_ASSOC) as $rw) $rewardsById[(int)$rw['id']] = $rw;

            // Product rewards must arrive as matching 0-price cart lines tagged with reward_id.
            $rewardLineQty = [];
            foreach ($cart as $item) {
                $rid = intval($item['reward_id'] ?? 0);
                if ($rid > 0) $rewardLineQty[$rid] = ($rewardLineQty[$rid] ?? 0) + floatval($item['quantity']);
            }

            $discountFromRewards = 0.00;
            $redeemCount = array_count_values($redeem_ids);
            foreach ($redeemCount as $rid => $times) {
                if (!isset($rewardsById[$rid])) {
                    $redeemFail(t('pos.redeem_err_reward_gone', 'ລາງວັນທີ່ເລືອກຖືກປິດ ຫຼື ລຶບໄປແລ້ວ — ກະລຸນາເລືອກໃໝ່'));
                }
                $rw = $rewardsById[$rid];
                $points_redeemed += intval($rw['points_cost']) * $times;
                if ($rw['reward_type'] === 'product') {
                    if (abs(($rewardLineQty[$rid] ?? 0) - intval($rw['product_qty']) * $times) > 0.0001) {
                        $redeemFail(t('pos.redeem_err_mismatch', 'ລາຍການແລກຄະແນນໃນກະຕ່າບໍ່ຖືກຕ້ອງ — ກະລຸນາແລກໃໝ່'));
                    }
                } else {
                    // A discount reward needs the purchase to reach its minimum AND to be more
                    // than the discount itself (same rule the POS applies before redeeming).
                    $rwMinSpend = floatval($rw['min_spend'] ?? 0);
                    if ($subtotal < $rwMinSpend || $subtotal <= floatval($rw['discount_amount'])) {
                        $redeemFail(sprintf(t('pos.redeem_err_min_spend', 'ຍອດຊື້ບໍ່ຮອດເງື່ອນໄຂຂອງ "%s" — ຕ້ອງຊື້ຢ່າງໜ້ອຍ %s ₭'), $rw['reward_name'], number_format(max($rwMinSpend, floatval($rw['discount_amount']) + 1))));
                    }
                    $discountFromRewards += floatval($rw['discount_amount']) * $times;
                }
                $redeem_notes[] = $rw['reward_name'] . ($times > 1 ? ' ×' . $times : '');
            }
            foreach ($rewardLineQty as $rid => $q) {
                if (!isset($redeemCount[$rid])) {
                    $redeemFail(t('pos.redeem_err_mismatch', 'ລາຍການແລກຄະແນນໃນກະຕ່າບໍ່ຖືກຕ້ອງ — ກະລຸນາແລກໃໝ່'));
                }
            }
            if ($discountFromRewards > 0 && $subtotal <= $discountFromRewards) {
                $redeemFail(sprintf(t('pos.redeem_err_min_spend', 'ຍອດຊື້ບໍ່ຮອດເງື່ອນໄຂຂອງ "%s" — ຕ້ອງຊື້ຢ່າງໜ້ອຍ %s ₭'), implode(', ', $redeem_notes), number_format($discountFromRewards + 1)));
            }
            if ($points_redeemed > intval($pointsAvailable)) {
                $redeemFail(sprintf(t('pos.redeem_err_not_enough', 'ຄະແນນບໍ່ພໍ: ມີ %s ຄະແນນ ແຕ່ຕ້ອງໃຊ້ %s ຄະແນນ'), number_format(intval($pointsAvailable)), number_format($points_redeemed)));
            }
            // A discount reward can bring the bill down to 0, never below it.
            $points_discount = min($discountFromRewards, max(0, $subtotal - $discount_bill));
            $discount_bill += $points_discount;
        }

        $amount_after_discount = max(0, $subtotal - $discount_bill);
        $vat_amount = 0.00;
        $net_total = $amount_after_discount;

        if ($tax_type === 'exclusive' && $vat_percent > 0 && $vat_percent < 100) {
            // The shop's listed price is the net amount and the rate% is the tax's share of the
            // FINAL total (not of the net price) — e.g. a 75,000 item at 10% comes to 8,333.33
            // tax / 83,333.33 total, not a flat 7,500 add-on.
            $vat_amount = round($amount_after_discount * ($vat_percent / (100 - $vat_percent)), 2);
            $net_total = $amount_after_discount + $vat_amount;
        } elseif ($tax_type === 'inclusive' && $vat_percent > 0) {
            $vat_amount = round($amount_after_discount - ($amount_after_discount / (1 + ($vat_percent / 100))), 2);
            $net_total = $amount_after_discount;
        }

        $total_paid = $cash_received + $qr_received;
        $change = max(0, $total_paid - $net_total);

        // ===== ຂາຍຕິດໜີ້ (credit sale) =====
        // Whatever was paid now is a deposit; the rest becomes a customer_debts row (inserted
        // below, inside this same transaction). Needs a real customer and the add right.
        $credit_amount = 0.00;
        if ($pay_mode === 'credit') {
            $creditFail = function ($msg) use ($pdo) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                echo json_encode(['success' => false, 'message' => $msg]);
                exit();
            };
            if (!hasPermission('customer_debt', 'add')) {
                $creditFail(t('pos.credit_err_permission', 'ທ່ານບໍ່ມີສິດຂາຍຕິດໜີ້!'));
            }
            $credCust = $pdo->prepare("SELECT customer_id FROM customers WHERE customer_id = ? AND (store_id = ? OR store_id = 0)");
            $credCust->execute([intval($customer_id), getPosStoreId()]);
            if (intval($customer_id) <= 0 || !$credCust->fetchColumn()) {
                $creditFail(t('pos.credit_err_customer', 'ກະລຸນາເລືອກລູກຄ້າກ່ອນຂາຍຕິດໜີ້'));
            }
            $deposit = min($total_paid, $net_total);
            $credit_amount = round($net_total - $deposit, 2);
            if ($credit_amount <= 0) {
                $creditFail(t('pos.credit_err_nothing', 'ເງິນມັດຈຳຄົບຍອດບິນແລ້ວ — ກະລຸນາໃຊ້ການຊຳລະປົກກະຕິ'));
            }
            // Deposit never produces change; keep cash/qr summing to the deposit exactly.
            if ($total_paid > $deposit) {
                $qr_received   = min($qr_received, $deposit);
                $cash_received = $deposit - $qr_received;
            }
            $total_paid   = $deposit;
            $change       = 0;
            $payment_type = 'ຕິດໜີ້';
        }

        // Net bill value expressed in the tendered currency (KIP amount / rate).
        $paid_amount_foreign = ($paid_currency === 'KIP')
            ? round($net_total, 2)
            : round($net_total / $paid_rate, 2);

        // Generate daily resetting invoice number starting from 0001 (Format: YYYYMMDD-0001)
        $todayDate = date('Y-m-d');
        $todayStr  = date('Ymd');

        $stmtSeq = $pdo->prepare("SELECT COUNT(*) FROM tbsale_save WHERE sale_date = :today_date");
        $stmtSeq->execute([':today_date' => $todayDate]);
        $todayCount = intval($stmtSeq->fetchColumn() ?? 0);
        $nextSeq = $todayCount + 1;

        $invoice_no = $todayStr . '-' . str_pad($nextSeq, 4, '0', STR_PAD_LEFT);
        // Queue number: same daily-resetting counter, zero-padded to 2 digits (01, 02, ... 10).
        $queue_display = str_pad((string)$nextSeq, 2, '0', STR_PAD_LEFT);
        $activeStoreId = getPosStoreId();

        // ບິນຂາຍຕິດໜີ້: ລະຫັດສາຂານຳໜ້າ (ເຊັ່ນ 1-20261006-0003) ເພື່ອແຍກໃຫ້ເຫັນວ່າເປັນໜີ້ຂອງສາຂາໃດ.
        // The daily sequence is shared with normal bills, so the number stays unique either way.
        if ($credit_amount > 0) {
            $scStmt = $pdo->prepare("SELECT store_code FROM tbstore WHERE store_id = ? LIMIT 1");
            $scStmt->execute([$activeStoreId]);
            $storeCode = trim((string)$scStmt->fetchColumn());
            if ($storeCode === '') $storeCode = (string)$activeStoreId;
            $invoice_no = $storeCode . '-' . $invoice_no;
        }

        $bank_account_id = isset($_POST['bank_account_id']) && intval($_POST['bank_account_id']) > 0 ? intval($_POST['bank_account_id']) : null;
        $bank_name = isset($_POST['bank_name']) && trim($_POST['bank_name']) !== '' ? trim($_POST['bank_name']) : null;

        if (empty($bank_account_id) && ($qr_received > 0 || strpos($payment_type, 'ໂອນ') !== false || strpos($payment_type, 'QR') !== false || strpos($payment_type, 'Transfer') !== false)) {
            try {
                // This branch's own banks, plus any shared across every branch (store_id = 0).
                $bStmt = $pdo->prepare("SELECT * FROM bank_accounts WHERE is_active = 1 AND (store_id = ? OR store_id = 0) ORDER BY id ASC LIMIT 1");
                $bStmt->execute([$activeStoreId]);
                $bank_info = $bStmt->fetch(PDO::FETCH_ASSOC);
                if ($bank_info) {
                    $bank_account_id = intval($bank_info['id']);
                    $bank_name = $bank_info['bank_name'];
                }
            } catch (Throwable $e) {}
        } else if ($bank_account_id) {
            try {
                $bStmt = $pdo->prepare("SELECT * FROM bank_accounts WHERE id = ? AND (store_id = ? OR store_id = 0)");
                $bStmt->execute([$bank_account_id, $activeStoreId]);
                $bank_info = $bStmt->fetch(PDO::FETCH_ASSOC);
                if ($bank_info && !empty($bank_info['bank_name'])) {
                    $bank_name = $bank_info['bank_name'];
                }
            } catch (Throwable $e) {}
        }

        // Insert into tbsale_save
        $stmtSave = $pdo->prepare("
            INSERT INTO tbsale_save (sale_save_bill, sale_date, sale_time, user_receive, customer_id, customer_name, ip_address, sale_qty, sale_amount, sale_discount_bill, sale_barlance, sale_pay, sale_return, type_pay, bank_account_id, bank_name, sale_status, store_id, paid_currency, paid_rate, paid_amount_foreign, queue_no, cash_received, qr_received)
            VALUES (:invoice_no, CURDATE(), CURTIME(), :user_id, :customer_id, :customer_name, :ip_address, :sale_qty, :sale_amount, :discount_bill, :net_total, :cash_received, :change, :payment_type, :bank_account_id, :bank_name, 'SUCCESS', :store_id, :paid_currency, :paid_rate, :paid_amount_foreign, :queue_no, :cash_received_col, :qr_received_col)
        ");
        $stmtSave->execute([
            ':invoice_no'      => $invoice_no,
            ':queue_no'        => $queue_display,
            ':user_id'         => $user_receive_name,
            ':customer_id'     => $customer_id,
            ':customer_name'   => $customer_name,
            ':ip_address'      => $client_ip,
            ':sale_qty'        => $total_qty,
            ':sale_amount'     => $subtotal,
            ':discount_bill'   => $discount_bill,
            ':net_total'       => $net_total,
            ':cash_received'   => $cash_received,
            ':change'          => $change,
            ':payment_type'    => $payment_type,
            ':bank_account_id' => $bank_account_id,
            ':bank_name'       => $bank_name,
            ':store_id'        => $activeStoreId,
            ':paid_currency'      => $paid_currency,
            ':paid_rate'         => $paid_rate,
            ':paid_amount_foreign' => $paid_amount_foreign,
            ':cash_received_col' => $cash_received,
            ':qr_received_col'   => $qr_received
        ]);

        // Insert into physical sales table with tax details
        try {
            $stmtSalesTable = $pdo->prepare("
                INSERT INTO sales (invoice_number, sold_by, customer_id, customer_name, subtotal, discount_amount, vat_amount, tax_type, vat_rate, total_amount, cash_received, change_amount, payment_type, bank_account_id, bank_name, status, store_id, created_at, paid_currency, paid_rate, paid_amount_foreign)
                VALUES (:invoice_no, :sold_by_id, :customer_id, :customer_name, :subtotal, :discount_bill, :vat_amount, :tax_type, :vat_rate, :net_total, :cash_received, :change, :payment_type, :bank_account_id, :bank_name, 'SUCCESS', :store_id, NOW(), :paid_currency, :paid_rate, :paid_amount_foreign)
                ON DUPLICATE KEY UPDATE subtotal = :subtotal, discount_amount = :discount_bill, vat_amount = :vat_amount, tax_type = :tax_type, vat_rate = :vat_rate, total_amount = :net_total, bank_account_id = :bank_account_id, bank_name = :bank_name, store_id = :store_id, paid_currency = :paid_currency, paid_rate = :paid_rate, paid_amount_foreign = :paid_amount_foreign
            ");
            $stmtSalesTable->execute([
                ':invoice_no'      => $invoice_no,
                ':sold_by_id'      => $sold_by_id,
                ':customer_id'     => $customer_id,
                ':customer_name'   => $customer_name,
                ':subtotal'        => $subtotal,
                ':discount_bill'   => $discount_bill,
                ':vat_amount'      => $vat_amount,
                ':tax_type'        => $tax_type,
                ':vat_rate'        => $vat_percent,
                ':net_total'       => $net_total,
                ':cash_received'   => $cash_received,
                ':change'          => $change,
                ':payment_type'    => $payment_type,
                ':bank_account_id' => $bank_account_id,
                ':bank_name'       => $bank_name,
                ':store_id'        => $activeStoreId,
                ':paid_currency'      => $paid_currency,
                ':paid_rate'         => $paid_rate,
                ':paid_amount_foreign' => $paid_amount_foreign
            ]);
        } catch (Throwable $ex) {}
        
        // Insert into tbsale_save_detail and update inventory
        $stmtDetail = $pdo->prepare("
            INSERT INTO tbsale_save_detail (save_bill, save_date, save_time, save_proid, save_proname, save_qty, save_price, save_orig_price, is_reward, cost_price, save_money, save_net_money, user_receives, multiplier)
            VALUES (:save_bill, CURDATE(), CURTIME(), :save_proid, :save_proname, :save_qty, :save_price, :save_orig_price, :is_reward, :cost_price, :save_money, :save_net_money, :user_receives, :multiplier)
        ");
        
        $stmtUpdateStock = $pdo->prepare("
            UPDATE products SET qty = qty - :deduct_qty WHERE product_id = :product_id AND store_id = :store_id
        ");

        $stmtCheckStock = $pdo->prepare("
            SELECT product_name, qty, cut_qty FROM products WHERE product_id = :pid AND store_id = :store_id FOR UPDATE
        ");
        
        $details_summary = [];
        $updated_stocks = [];
        
        foreach ($cart as $item) {
            $pid = intval($item['product_id']);
            $proname = $item['product_name'] . ' (' . $item['unit_name'] . ')';
            $qty = floatval($item['quantity']);
            $price = floatval($item['unit_price']);
            $cost = floatval($item['cost_price']);
            $multiplier = intval($item['multiplier'] ?? 1);
            $total_item = $qty * $price;
            $deduct_stock_qty = $qty * $multiplier;

            $is_gift = !empty($item['is_free_gift']) || $price == 0 || strpos($item['product_name'], '(ແຖມ)') !== false;
            // A points-reward product is a real item leaving the shelf — it gets the normal
            // stock check below, not the promo-gift shortcut.
            $is_reward_line = intval($item['reward_id'] ?? 0) > 0;

            if ($is_gift && !$is_reward_line) {
                $stmtCheckStock->execute([':pid' => $pid, ':store_id' => $activeStoreId]);
                $pData = $stmtCheckStock->fetch();
                $shouldCutQty = $pData ? intval($pData['cut_qty'] ?? 0) : 0;
                $currentDbStock = $pData ? floatval($pData['qty']) : 0;
            } else {
                $stmtCheckStock->execute([':pid' => $pid, ':store_id' => $activeStoreId]);
                $pData = $stmtCheckStock->fetch();
                if (!$pData) {
                    if ($pdo->inTransaction()) $pdo->rollBack();
                    echo json_encode(['success' => false, 'message' => "ບໍ່ພົບຂໍ້ມູນສິນຄ້າ ID: {$pid} ໃນລະບົບ!"]);
                    exit();
                }

                $shouldCutQty = intval($pData['cut_qty'] ?? 1); // 1=ຕັດ qty, 0=ບໍ່ຕັດ qty
                $currentDbStock = floatval($pData['qty']);

                if ($shouldCutQty) {
                    if ($currentDbStock <= 0) {
                        if ($pdo->inTransaction()) $pdo->rollBack();
                        echo json_encode(['success' => false, 'message' => "ສິນຄ້າ \"{$pData['product_name']}\" ໝົດແລ້ວ! ບໍ່ສາມາດຂາຍໄດ້"]);
                        exit();
                    }

                    if ($currentDbStock < $deduct_stock_qty) {
                        if ($pdo->inTransaction()) $pdo->rollBack();
                        echo json_encode(['success' => false, 'message' => "ສິນຄ້າ \"{$pData['product_name']}\" ເຫຼືອພຽງ {$currentDbStock} ອັນ! ບໍ່ພໍສຳລັບການຂາຍ"]);
                        exit();
                    }
                }
            }
            
            $stmtDetail->execute([
                ':save_bill'    => $invoice_no,
                ':save_proid'   => $pid,
                ':save_proname' => $proname,
                ':save_qty'     => $qty,
                ':save_price'   => $price,
                // pre-promotion unit price + reward flag, so a reprint draws this line exactly
                // like the checkout receipt did (struck-through price / [reward] tag)
                ':save_orig_price' => floatval($item['original_price'] ?? $price),
                ':is_reward'    => !empty($is_reward_line) ? 1 : 0,
                ':cost_price'   => $cost,
                ':save_money'   => $total_item,
                ':save_net_money'=> $total_item,
                ':user_receives'=> $user_receive_name,
                ':multiplier'   => $multiplier
            ]);
            
            $newStock = $currentDbStock;
            // ຕັດ qty ສະເພາະສິນຄ້າທີ່ cut_qty = 1 ເທົ່ານັ້ນ
            if ($shouldCutQty) {
                $stmtUpdateStock->execute([
                    ':deduct_qty' => $deduct_stock_qty,
                    ':product_id' => $pid,
                    ':store_id'   => $activeStoreId
                ]);
                $newStock = max(0, $currentDbStock - $deduct_stock_qty);
            }

            $updated_stocks[] = [
                'product_id' => $pid,
                'new_qty'    => $newStock,
                'cut_qty'    => $shouldCutQty
            ];

            $unit_name = trim($item['unit_name'] ?? '');
            $proname = $item['product_name'] . ($unit_name !== '' ? ' (' . $unit_name . ')' : '');
            $orig_price = floatval($item['original_price'] ?? $price);
            $is_gift = !empty($item['is_free_gift']) || $price == 0 || strpos($item['product_name'], '(ແຖມ)') !== false;

            $details_summary[] = [
                'proname'        => $proname,
                'unit_name'      => $unit_name,
                'qty'            => $qty,
                'price'          => $price,
                'original_price' => $orig_price,
                'is_free_gift'   => $is_gift,
                'is_reward'      => $is_reward_line,
                'total'          => $total_item
            ];
        }
        
        // ===== ລູກຄ້າຕິດໜີ້: record the unpaid part of a credit sale =====
        // Not wrapped in a try/catch: a credit sale without its debt row must roll back.
        $credit_due_date = null;
        if ($credit_amount > 0) {
            // ກຳນົດຊຳລະ (optional): a real yyyy-mm-dd date, not in the past
            $dueIn = trim((string)($_POST['due_date'] ?? ''));
            if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $dueIn) && strtotime($dueIn) !== false && $dueIn >= date('Y-m-d')) {
                $credit_due_date = $dueIn;
            }
            $pdo->prepare("INSERT INTO customer_debts (store_id, customer_id, customer_name, invoice_number, bill_amount, deposit_amount, amount, paid_amount, balance, status, due_date, note, created_by, created_at)
                           VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, 'unpaid', ?, NULL, ?, NOW())")
                ->execute([$activeStoreId, intval($customer_id), $customer_name, $invoice_no, $net_total, $total_paid, $credit_amount, $credit_amount, $credit_due_date, $user_receive_name]);
        }

        // ===== CUSTOMER LOYALTY POINTS =====
        // 1. Spend the redeemed points (validated + locked above). Not wrapped in a
        //    try/catch: if this fails the whole sale must roll back, or the customer would
        //    get the reward without the points being taken.
        $points_earned = 0;
        $customer_points_balance = 0;
        $loyalty_active = 0;
        if ($points_redeemed > 0) {
            changeCustomerPoints($pdo, $customer_id, -$points_redeemed, 'redeem', $invoice_no, implode(', ', $redeem_notes), $activeStoreId);
            $pdo->prepare("UPDATE tbsale_save SET points_redeemed = ?, points_discount = ? WHERE sale_save_bill = ?")
                ->execute([$points_redeemed, $points_discount, $invoice_no]);
        }
        // 2. Earn Y points for every X kip actually paid — $net_total is already after the
        //    points discount, so a redeemed discount doesn't earn points back on itself.
        if (!empty($customer_id) && intval($customer_id) > 0) {
            if (getSetting($pdo, 'loyalty_enabled', '0') === '1') {
                $loyalty_active = 1;
                $lpSpend = (int)getSetting($pdo, 'loyalty_spend_amount', '100000');
                $lpPer   = (int)getSetting($pdo, 'loyalty_points_earned', '1');
                if ($lpSpend > 0 && $lpPer > 0) {
                    $points_earned = intdiv((int)round($net_total), $lpSpend) * $lpPer;
                    if ($points_earned > 0) {
                        try {
                            changeCustomerPoints($pdo, $customer_id, $points_earned, 'earn', $invoice_no, null, $activeStoreId);
                            $pdo->prepare("UPDATE tbsale_save SET points_earned = ? WHERE sale_save_bill = ?")
                                ->execute([$points_earned, $invoice_no]);
                        } catch (Throwable $e) { $points_earned = 0; }
                    }
                }
            }
            try {
                $cpStmt = $pdo->prepare("SELECT points FROM customers WHERE customer_id = ?");
                $cpStmt->execute([intval($customer_id)]);
                $customer_points_balance = (int)$cpStmt->fetchColumn();
            } catch (Throwable $e) {}
        }

        $pdo->commit();

        $responsePayload = [
            'success'        => true,
            'points_earned'   => $points_earned,
            'points_redeemed' => $points_redeemed,
            'points_discount' => $points_discount,
            'customer_id'     => $customer_id,
            'customer_points' => $customer_points_balance,
            'loyalty_active'  => $loyalty_active,
            'invoice_number' => $invoice_no,
            'queue_number'   => $queue_display,
            'date'           => date('d/m/Y H:i'),
            'cashier'        => $user_receive_name,
            'customer_name'  => $customer_name,
            'customer_phone' => trim($_POST['customer_phone'] ?? ''),
            'subtotal'       => $subtotal,
            'discount_amount'=> $discount_bill,
            'tax_type'       => $tax_type,
            'vat_rate'       => $vat_percent,
            'vat_amount'     => $vat_amount,
            'total_amount'   => $net_total,
            'paid_currency'  => $paid_currency,
            'paid_rate'      => $paid_rate,
            'cash_received'  => $cash_received,
            'qr_received'    => $qr_received,
            'pay_mode'       => $pay_mode,
            'change'         => $change,
            'credit_amount'  => $credit_amount,
            'credit_due_date'=> $credit_due_date ? date('d/m/Y', strtotime($credit_due_date)) : '',
            'payment_type'   => $payment_type,
            'bank_account_id'=> $bank_account_id,
            'bank_name'      => $bank_name,
            'bank_account_no'=> $bank_info['account_number'] ?? '',
            'bank_account_name'=> $bank_info['account_name'] ?? '',
            'bank_qr_img'    => resolveBankQr($bank_info['qr_code_img'] ?? '', $bank_info['bank_code'] ?? ''),
            'details'        => $details_summary,
            'updated_stocks' => $updated_stocks
        ];

        // Remember this exact request so a duplicate arriving within the window above (see the
        // idempotency guard) replays this same successful response instead of billing twice.
        $_SESSION['pos_last_checkout_fp']       = $idemFp;
        $_SESSION['pos_last_checkout_time']     = time();
        $_SESSION['pos_last_checkout_response'] = $responsePayload;

        if (ob_get_length()) ob_clean();
        echo json_encode($responsePayload);
        exit();
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        if (ob_get_length()) ob_clean();
        echo json_encode(['success' => false, 'message' => 'ເກີດຂໍ້ຜິດພາດ: ' . $e->getMessage()]);
        exit();
    }
}

// 2. AJAX handler for Quick Add Customer
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_customer_ajax') {
    header('Content-Type: application/json');
    $c_name        = trim($_POST['customer_name'] ?? '');
    $c_phone       = trim($_POST['phone'] ?? '');
    $c_address     = trim($_POST['address'] ?? '');
    $c_code        = trim($_POST['customer_code'] ?? '');
    $c_member_card = trim($_POST['member_card'] ?? '');
    $c_notes       = trim($_POST['notes'] ?? '');

    if (empty($c_name)) {
        echo json_encode(['success' => false, 'message' => 'ກະລຸນາປ້ອນຊື່ລູກຄ້າ!']);
        exit();
    }

    $activePosStoreId = getPosStoreId();
    if (empty($c_code)) {
        $stmtSeq = $pdo->prepare("SELECT IFNULL(MAX(customer_id), 0) + 1 FROM customers WHERE store_id = ?");
        $stmtSeq->execute([$activePosStoreId]);
        $maxCusId = (int)$stmtSeq->fetchColumn();
        $c_code = 'CUST-' . str_pad($activePosStoreId, 2, '0', STR_PAD_LEFT) . '-' . str_pad($maxCusId, 3, '0', STR_PAD_LEFT);
    }

    try {
        $stmtIns = $pdo->prepare("INSERT INTO customers (customer_code, customer_name, phone, address, member_card, notes, store_id, created_at) VALUES (:code, :name, :phone, :address, :card, :notes, :store_id, NOW())");
        $stmtIns->execute([
            ':code'     => $c_code,
            ':name'     => $c_name,
            ':phone'    => $c_phone,
            ':address'  => $c_address,
            ':card'     => $c_member_card,
            ':notes'    => $c_notes,
            ':store_id' => $activePosStoreId
        ]);
        $new_id = $pdo->lastInsertId();

        echo json_encode([
            'success' => true,
            'customer' => [
                'customer_id'   => $new_id,
                'customer_code' => $c_code,
                'customer_name' => $c_name,
                'phone'         => $c_phone,
                'address'       => $c_address,
                'member_card'   => $c_member_card,
                'notes'         => $c_notes
            ]
        ]);
        exit();
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'ຜິດພາດ: ' . $e->getMessage()]);
        exit();
    }
}

// Auto-deactivate expired promotions & Fetch active promotions for current branch/store
$activePromos = [];
try {
    // Scope promos to the branch the POS is actually operating as (honours ?switch_store_id
    // for admin/main-branch users), matching how products/categories are scoped below.
    $currentPosStoreId = getPosStoreId();
    $pdo->exec("UPDATE promotions SET status = 0 WHERE status = 1 AND end_date < CURDATE()");
    $stmtActivePromos = $pdo->prepare("
        SELECT * FROM promotions 
        WHERE status = 1 
          AND (branch_id = ? OR branch_id = 0)
          AND CURDATE() BETWEEN start_date AND end_date 
        ORDER BY id DESC
    ");
    $stmtActivePromos->execute([$currentPosStoreId]);
    $activePromos = $stmtActivePromos->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {}

// Loosen string comparison so a promo's free-typed target still matches the real product/
// category name despite spacing, casing, zero-width chars or Unicode form differences
// (common with Lao text entered by hand).
function promoNormalizeName($s) {
    $s = (string)$s;
    if (class_exists('Normalizer')) {
        $n = Normalizer::normalize($s, Normalizer::FORM_C);
        if ($n !== false) $s = $n;
    }
    // Fold the two ways Lao vowels get typed: ເ+ເ vs ແ, and ເ+ໂ etc. (ແກັດ vs ເເກັດ, ແກ້ວ vs ເເກ້ວ)
    $s = str_replace(["\u{0EC0}\u{0EC0}", "\u{0EC0}\u{0EC1}"], "\u{0EC1}", $s);
    // drop zero-width / BOM / all whitespace, then lowercase
    $s = preg_replace('/[\x{200B}-\x{200D}\x{FEFF}\s]+/u', '', $s);
    return mb_strtolower(trim($s));
}
function promoNameMatches($actual, $target) {
    $a = promoNormalizeName($actual);
    $t = promoNormalizeName($target);
    if ($a === '' || $t === '') return false;
    return $a === $t || mb_stripos($a, $t) !== false || mb_stripos($t, $a) !== false;
}
// Unit matching must be EXACT (after normalising) — never substring. BeerLao's ປ໋ອງຍາວ and
// ປ໋ອງສັ້ນ share the "ປ໋ອງ" prefix, so a loose match would discount both when a promo names
// only one. "all"/empty means every unit.
function promoUnitMatches($actualUnit, $targetUnit) {
    $t = promoNormalizeName($targetUnit);
    if ($t === '' || $t === 'all') return true;
    return promoNormalizeName($actualUnit) === $t;
}

function getProductPromotion($product, $activePromos, $dispCur = null) {
    if (empty($activePromos)) return null;

    $pName = trim($product['product_name'] ?? '');
    $cName = trim($product['category_name'] ?? '');
    // Codes a promo's target may be entered as instead of the product name
    $pCodes = array_filter([
        trim((string)($product['barcode'] ?? '')),
        trim((string)($product['code1'] ?? '')),
        trim((string)($product['product_id'] ?? '')),
    ], 'strlen');

    $matchedDiscountPromo = null;
    $matchedGiftPromo = null;

    foreach ($activePromos as $promo) {
        $targetType = $promo['target_type'] ?? 'all';
        $targetName = trim($promo['target_name'] ?? '');

        // Match the promo to the PRODUCT (or its category, or "all"). Unit scoping is applied
        // later, per sellable unit — a promo aimed at one unit (e.g. ແກັດ) still "belongs" to
        // the product; its other units simply stay at full price.
        $isMatch = false;
        if ($targetType === 'all' || empty($targetName) || $targetName === 'ທຸກສິນຄ້າ') {
            $isMatch = true;
        } elseif ($targetType === 'category') {
            $isMatch = (!empty($cName) && promoNameMatches($cName, $targetName));
        } elseif ($targetType === 'product') {
            $isMatch = (!empty($pName) && promoNameMatches($pName, $targetName))
                       || in_array($targetName, $pCodes, true);
        }
        if (!$isMatch) continue;

        if (floatval($promo['discount_value'] ?? 0) > 0 && !$matchedDiscountPromo) {
            $matchedDiscountPromo = $promo;
        }
        if (trim($promo['gift_product_name'] ?? '') !== '' && !$matchedGiftPromo) {
            $matchedGiftPromo = $promo;
        }
        if ($matchedDiscountPromo && $matchedGiftPromo) break;
    }

    $promoToUse = $matchedDiscountPromo ?? $matchedGiftPromo;
    if (!$promoToUse) return null;

    $promoType = $promoToUse['promo_type'] ?? 'discount';
    $discType  = $promoToUse['discount_type'] ?? 'percentage';
    $discVal   = floatval($promoToUse['discount_value'] ?? 0);
    $giftName  = trim($matchedGiftPromo['gift_product_name'] ?? $promoToUse['gift_product_name'] ?? '');
    $giftQty   = intval($matchedGiftPromo['gift_qty'] ?? $promoToUse['gift_qty'] ?? 1);
    if ($giftQty < 1) $giftQty = 1;

    $tunit = trim($promoToUse['target_unit_name'] ?? 'all');
    if ($tunit === '') $tunit = 'all';
    $unitSuffix = ($tunit !== 'all') ? ' (ສະເພາະ ' . $tunit . ')' : '';

    // Discount descriptor (unit-agnostic — the actual amount is computed per selected unit).
    // A fixed ₭ amount is shown converted into the POS's active display currency.
    $discountText = '';
    if ($discType === 'percentage' && $discVal > 0) {
        $discountText = 'ຫຼຸດ ' . (floor($discVal) == $discVal ? intval($discVal) : number_format($discVal, 1)) . '%';
    } elseif ($discVal > 0) {
        $curCode = strtoupper((string)($dispCur['code'] ?? 'KIP'));
        if ($curCode !== 'KIP' && function_exists('convertFromKip')) {
            $amt = convertFromKip($discVal, $curCode, $dispCur['rates'] ?? null);
            $dec = (int)($dispCur['decimals'] ?? 2);
            $sym = (string)($dispCur['symbol'] ?? $curCode);
            $discountText = 'ຫຼຸດ ' . number_format((float)$amt, $dec, '.', ',') . ' ' . $sym;
        } else {
            $discountText = 'ຫຼຸດ ' . number_format($discVal) . '₭';
        }
    }
    $giftText = ($giftName !== '') ? ('ແຖມ ' . $giftName . ($giftQty > 1 ? ' x' . $giftQty : '')) : '';

    // Badge always leads with the promo name so the cashier can see which promo is in effect
    $parts = array_values(array_filter([$discountText, $giftText]));
    $badge = trim($promoToUse['promo_name'] ?? '') !== '' ? trim($promoToUse['promo_name']) : 'ໂປຣ';
    if ($parts) $badge .= ' · ' . implode(' + ', $parts);
    $badge .= $unitSuffix;

    return [
        'promo_name'        => $promoToUse['promo_name'] ?? '',
        'promo_type'        => $promoType,
        'discount_type'     => $discType,
        'discount_value'    => $discVal,
        'badge'             => $badge,
        'min_qty'           => intval($promoToUse['min_qty'] ?? 0),
        'min_amount'        => floatval($promoToUse['min_amount'] ?? 0),
        'gift_product_name' => $giftName,
        'gift_qty'          => $giftQty,
        'target_unit_name'  => $tunit
    ];
}

// Apply a promo to ONE sellable unit. Returns [originalPrice, effectivePrice, wasDiscounted].
// The discount only bites when the promo targets "all" units or this unit's name — so a promo
// scoped to ແກັດ leaves ຫໍ່ (and every other unit) untouched.
function applyPromoToUnit($promo, $unitName, $unitPrice) {
    $unitPrice = floatval($unitPrice);
    $hit = promoUnitMatches($unitName, $promo['target_unit_name'] ?? 'all');
    if (!$hit || floatval($promo['discount_value'] ?? 0) <= 0) {
        return [$unitPrice, $unitPrice, false];
    }
    $dv = floatval($promo['discount_value']);
    if (($promo['discount_type'] ?? 'percentage') === 'percentage') {
        $eff = $unitPrice - ($unitPrice * $dv / 100);
    } else {
        $eff = $unitPrice - $dv;
    }
    return [$unitPrice, max(0, round($eff)), true];
}

// Fetch categories, products, and customers list
$activeStoreId = getPosStoreId();
$categoriesStmt = $pdo->prepare("SELECT * FROM categories WHERE store_id = ? ORDER BY category_name ASC");
$categoriesStmt->execute([$activeStoreId]);
$categories = $categoriesStmt->fetchAll();

// The customer receipt's own printer, if THIS branch designated one (Settings > Printers).
// Each branch sets and prints through its own receipt printer. Read first: the kitchen routes
// below must never point back at it.
$posReceiptPrinter = null;
$posReceiptPrinterIp = '';
try {
    $rpStmt = $pdo->prepare("SELECT id, name, type, paper_width, ip_address FROM tbl_printer WHERE is_receipt_printer = 1 AND status = 1 AND branch_id = ? LIMIT 1");
    $rpStmt->execute([$activeStoreId]);
    $rpRow = $rpStmt->fetch();
    if ($rpRow) {
        $posReceiptPrinter = [
            'printer_id'   => (int)$rpRow['id'],
            'printer_name' => $rpRow['name'],
            'printer_type' => in_array($rpRow['type'] ?? '', ['ip', 'usb'], true) ? 'ip' : 'browser', // 'ip' = direct (LAN or USB)
            'paper_width'  => intval($rpRow['paper_width'] ?? 80) === 58 ? 58 : 80,
        ];
        $posReceiptPrinterIp = strtolower(trim((string)($rpRow['ip_address'] ?? '')));
    }
} catch (Throwable $e) {}

// Kitchen / category tickets: category_id => {printer_id, printer_name, printer_type, paper_width}.
// At checkout the main bill goes ONLY to the receipt printer above, and each category's items go
// as a separate ticket to the printer set on that category. A category pointed at the receipt
// printer itself (same printer, or another entry with the same IP) gets no ticket — otherwise the
// main printer prints the bill plus a duplicate slip. 'ip' tickets go over the LAN (through the
// print agent when print_mode = agent, like the receipt); 'browser' tickets open a print dialog.
// Switch all category tickets off with POS_PRINT_KITCHEN_TICKETS in config/db.php.
$posKitchenRoutes = [];
if (!defined('POS_PRINT_KITCHEN_TICKETS') || POS_PRINT_KITCHEN_TICKETS) try {
    $krStmt = $pdo->prepare("
        SELECT p.*, c.category_id, c.printer_id, p.name AS printer_name
        FROM categories c
        JOIN tbl_printer p ON p.id = c.printer_id AND p.status = 1 AND p.branch_id = c.store_id
        WHERE c.store_id = ? AND c.printer_id IS NOT NULL
    ");
    $krStmt->execute([$activeStoreId]);
    foreach ($krStmt->fetchAll() as $kr) {
        $krType = in_array($kr['type'] ?? '', ['ip', 'usb'], true) ? 'ip' : 'browser'; // 'ip' = direct (LAN or USB)
        $krIp = strtolower(trim((string)($kr['ip_address'] ?? '')));
        if ($posReceiptPrinter) {
            if ((int)$kr['printer_id'] === $posReceiptPrinter['printer_id']) continue;
            if ($krType === 'ip' && $krIp !== '' && $krIp === $posReceiptPrinterIp) continue;
        }
        $posKitchenRoutes[(string)$kr['category_id']] = [
            'printer_id'   => (int)$kr['printer_id'],
            'printer_name' => $kr['printer_name'],
            'printer_type' => $krType,
            'paper_width'  => intval($kr['paper_width'] ?? 80) === 58 ? 58 : 80,
        ];
    }
} catch (Throwable $e) {}

$productsStmt = $pdo->prepare("
    SELECT p.*, c.category_name 
    FROM products p 
    LEFT JOIN categories c ON p.category_id = c.category_id 
    WHERE p.store_id = ?
    ORDER BY p.code1 DESC, p.product_name ASC
");
$productsStmt->execute([$activeStoreId]);
$productsRaw = $productsStmt->fetchAll();

$stmtPosCust = $pdo->prepare("SELECT customer_id, customer_code, customer_name, phone, address, member_card, notes, points, created_at FROM customers WHERE store_id = ? OR store_id = 0 ORDER BY customer_id DESC");
$stmtPosCust->execute([$activeStoreId]);
$customersList = $stmtPosCust->fetchAll();

// Loyalty redemption catalogue for the "ແລກຄະແນນ" button. Product rewards are resolved in
// THIS branch (product_id repeats per store); one whose product doesn't exist here is dropped.
$posLoyalty = ['enabled' => getSetting($pdo, 'loyalty_enabled', '0') === '1', 'rewards' => []];
if ($posLoyalty['enabled']) {
    try {
        $lrStmt = $pdo->prepare("
            SELECT r.id, r.reward_name, r.points_cost, r.reward_type, r.discount_amount, r.min_spend, r.product_id, r.product_qty,
                   p.product_name, p.unit, p.price, p.bprice, p.img_url, p.category_id
            FROM loyalty_rewards r
            LEFT JOIN products p ON (r.reward_type = 'product' AND p.product_id = r.product_id AND p.store_id = ?)
            WHERE r.is_active = 1
            ORDER BY r.points_cost ASC, r.id ASC
        ");
        $lrStmt->execute([$activeStoreId]);
        foreach ($lrStmt->fetchAll(PDO::FETCH_ASSOC) as $lr) {
            if ($lr['reward_type'] === 'product' && $lr['product_name'] === null) continue;
            $posLoyalty['rewards'][] = [
                'id'              => (int)$lr['id'],
                'name'            => $lr['reward_name'],
                'points'          => (int)$lr['points_cost'],
                'type'            => $lr['reward_type'] === 'product' ? 'product' : 'discount',
                'discount_amount' => (float)$lr['discount_amount'],
                'min_spend'       => (float)$lr['min_spend'],
                'product_id'      => $lr['product_id'] !== null ? (int)$lr['product_id'] : null,
                'product_qty'     => max(1, (int)$lr['product_qty']),
                'product_name'    => $lr['product_name'],
                'unit'            => $lr['unit'],
                'price'           => (float)$lr['price'],
                'bprice'          => (float)$lr['bprice'],
                'image'           => $lr['img_url'],
                'category_id'     => $lr['category_id'],
            ];
        }
    } catch (Throwable $e) {}
}

// Fetch extra units
$extraUnits = $pdo->query("SELECT * FROM product_units ORDER BY multiplier ASC, id ASC")->fetchAll();
$unitsMap = [];
foreach ($extraUnits as $u) {
    $unitsMap[$u['product_id']][] = $u;
}

// Map products with complete unit structures and promotions
$posDisplayCurrency = function_exists('getDisplayCurrency') ? getDisplayCurrency($pdo) : ['code' => 'KIP'];
$products = [];
foreach ($productsRaw as $p) {
    $pid = $p['product_id'];
    $p['extra_units'] = $unitsMap[$pid] ?? [];

    $promo = getProductPromotion($p, $activePromos, $posDisplayCurrency);
    if ($promo) {
        // Price each unit independently so only the promo's target unit is discounted.
        list($bOrig, $bEff, $anyHit) = applyPromoToUnit($promo, $p['unit'] ?? '', $p['price']);
        $p['original_price'] = $bOrig;
        $p['price']          = $bEff;

        if (!empty($p['extra_units'])) {
            foreach ($p['extra_units'] as &$eu) {
                list($euOrig, $euEff, $euHit) = applyPromoToUnit($promo, $eu['unit_name'] ?? '', $eu['price']);
                $eu['original_price'] = $euOrig;
                $eu['price']          = $euEff;
                $anyHit = $anyHit || $euHit;
            }
            unset($eu);
        }

        $isGift = (trim($promo['gift_product_name'] ?? '') !== '');
        $p['has_promo']         = ($anyHit || $isGift);
        $p['promo_badge']       = $promo['badge'];
        $p['promo_name']        = $promo['promo_name'];
        $p['promo_type']        = $promo['promo_type'] ?? 'discount';
        $p['discount_type']     = $promo['discount_type'] ?? 'percentage';
        $p['discount_value']    = $promo['discount_value'] ?? 0;
        $p['gift_product_name'] = $promo['gift_product_name'] ?? '';
        $p['gift_qty']          = $promo['gift_qty'] ?? 1;
        $p['target_unit_name']  = $promo['target_unit_name'] ?? 'all';
        $p['promo_min_qty']     = $promo['min_qty'] ?? 0;
        $p['promo_min_amount']  = $promo['min_amount'] ?? 0;
    } else {
        $p['has_promo']       = false;
        $p['original_price']  = floatval($p['price']);
    }
    
    $products[] = $p;
}
