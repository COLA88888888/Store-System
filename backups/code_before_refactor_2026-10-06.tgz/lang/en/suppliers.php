<?php
// Suppliers page (English)
return [
    'suppliers.page_title'        => 'Manage Suppliers',
    'suppliers.btn_add'           => 'Add Supplier',
    'suppliers.btn_edit'          => 'Edit',
    'suppliers.btn_delete'        => 'Delete',
    'suppliers.btn_save'          => 'Save',
    'suppliers.btn_ok'            => 'OK',
    'suppliers.cancel'            => 'Cancel',
    'suppliers.clear'             => 'Clear',
    'suppliers.search_ph'         => 'Search name / phone / contact...',
    'suppliers.count_label'       => 'items',

    'suppliers.col_no'            => 'No.',
    'suppliers.col_name'          => 'Supplier Name',
    'suppliers.col_phone'         => 'Phone',
    'suppliers.col_contact'       => 'Contact Person',
    'suppliers.col_address'       => 'Address',
    'suppliers.col_products'      => 'Products',
    'suppliers.col_status'        => 'Status',
    'suppliers.col_action'        => 'Actions',
    'suppliers.empty'             => 'No suppliers yet',

    'suppliers.status_active'     => 'Active',
    'suppliers.status_inactive'   => 'Inactive',

    'suppliers.modal_add_title'   => 'Add Supplier',
    'suppliers.modal_edit_title'  => 'Edit Supplier',
    'suppliers.f_name'            => 'Supplier Name',
    'suppliers.f_phone'          => 'Phone',
    'suppliers.f_contact'         => 'Contact Person',
    'suppliers.f_address'         => 'Address',
    'suppliers.f_notes'           => 'Notes',
    'suppliers.f_status'          => 'Status',
    'suppliers.ph_name'           => 'e.g. Vientiane Wholesale Store',
    'suppliers.ph_phone'          => 'e.g. 020 5555 1234',
    'suppliers.ph_contact'        => 'Coordinator name',
    'suppliers.ph_address'        => 'Village / District / Province',
    'suppliers.ph_notes'          => 'Additional notes (optional)',

    'suppliers.msg_success_title' => 'Success',
    'suppliers.msg_error_title'   => 'Notice',
    'suppliers.del_confirm_title' => 'Confirm Delete',
    'suppliers.del_confirm_text'  => 'Delete supplier "{name}"?',
    'suppliers.del_yes'           => 'Delete',
    'suppliers.del_no'            => 'Cancel',
    'suppliers.validate_name'     => 'Please enter the supplier name!',

    // Previously untranslated labels
    'suppliers.no_result' => 'No suppliers match your search',

    // Pagination
    'suppliers.page_showing' => 'Showing',
    'suppliers.page_of' => 'of',
    'suppliers.page_page' => 'page',
    'suppliers.page_all' => 'All',
    'suppliers.page_items' => 'items',
];
