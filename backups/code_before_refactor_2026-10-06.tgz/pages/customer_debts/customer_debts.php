<?php
// Page: ລູກຄ້າຕິດໜີ້ (Customer debts)
// One row per customer who owes money — bills sold on credit at the POS plus opening balances
// entered here. Repayments are taken from this page (per bill, or oldest-first across all bills).
session_start();

$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
$base_path = (basename($scriptDir) === 'pages') ? '../' : '../../';

require_once __DIR__ . '/../../api/customer_debts_backend.php';

$canAddDebt    = hasPermission('customer_debt', 'add');
$canPayDebt    = hasPermission('customer_debt', 'edit');
$canCancelDebt = hasPermission('customer_debt', 'delete');

$statusTabs = [
    'open'    => t('customer_debt.tab_open', 'ຍັງຄ້າງຊຳລະ'),
    'overdue' => t('customer_debt.tab_overdue', 'ກາຍກຳນົດ'),
    'paid'    => t('customer_debt.tab_paid', 'ຊຳລະຄົບແລ້ວ'),
    'all'     => t('customer_debt.tab_all', 'ທັງໝົດ'),
];

require_once __DIR__ . '/../../layouts/header.php';
?>

<style>
  .cdb { font-family: 'Noto Sans Lao', 'Souliyo', 'Boon', sans-serif; color: #1e293b; }
  .cdb-title { font-size: 1.15rem; font-weight: 700; margin: 0; }
  .cdb-sub { font-size: 0.82rem; color: #64748b; }
  .cdb-stats { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 12px; }
  @media (max-width: 767.98px) { .cdb-stats { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
  .cdb-stat { position: relative; overflow: hidden; background: linear-gradient(135deg, var(--c), var(--d)); border-radius: 14px; padding: 22px 22px; min-height: 124px; color: #fff; box-shadow: 0 6px 16px rgba(15, 23, 42, .12); }
  .cdb-stat::after { content: ''; position: absolute; right: -24px; bottom: -34px; width: 130px; height: 130px; border-radius: 50%; background: rgba(255, 255, 255, .1); }
  .cdb-stat .lbl { font-size: 0.95rem; font-weight: 700; color: rgba(255, 255, 255, .95); }
  .cdb-stat .num { font-size: 1.85rem; font-weight: 800; line-height: 1.25; margin-top: 8px; word-break: break-all; }
  .cdb-stat .ico { position: absolute; right: 18px; top: 18px; width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; background: rgba(255, 255, 255, .22); font-size: 1.25rem; z-index: 1; }
  @media (max-width: 767.98px) { .cdb-stat { padding: 16px; min-height: 100px; } .cdb-stat .num { font-size: 1.25rem; } .cdb-stat .ico { display: none; } }

  .cdb-panel { background: #fff; border: 1px solid #e2e8f0; border-radius: 10px; }
  .cdb-filters { padding: 12px 14px; border-bottom: 1px solid #e2e8f0; display: flex; flex-wrap: wrap; gap: 10px; align-items: flex-end; }
  .cdb-filters label { font-size: 0.76rem; color: #64748b; margin-bottom: 3px; display: block; }
  .cdb-filters .form-control, .cdb-filters .btn { height: 36px; border-radius: 8px; font-size: 0.86rem; }
  .cdb-tabs { display: flex; flex-wrap: wrap; gap: 6px; }
  .cdb-tabs a { padding: 6px 12px; border-radius: 999px; font-size: 0.82rem; font-weight: 600; background: #f1f5f9; color: #475569; text-decoration: none; }
  .cdb-tabs a.active { background: #244886; color: #fff; }

  .cdb-table { margin: 0; font-size: 0.87rem; }
  .cdb-table thead th { background: #f8fafc; color: #64748b; font-size: 0.78rem; font-weight: 600; border-top: 0; border-bottom: 1px solid #e2e8f0; padding: 10px 12px; white-space: nowrap; }
  .cdb-table td { padding: 10px 12px; vertical-align: middle; border-top: 1px solid #f1f5f9; }
  .cdb-table tbody tr:hover { background: #fafbfc; }
  .cdb-name { font-weight: 600; }
  .cdb-meta { font-size: 0.76rem; color: #94a3b8; }
  .cdb-pill { display: inline-block; padding: 3px 10px; border-radius: 999px; font-size: 0.76rem; font-weight: 600; white-space: nowrap; }
  .cdb-pill.danger { background: #fef2f2; color: #b91c1c; }
  .cdb-pill.warning { background: #fffbeb; color: #b45309; }
  .cdb-pill.success { background: #f0fdf4; color: #15803d; }
  .cdb-pill.muted { background: #f1f5f9; color: #64748b; }
  .cdb-money { white-space: nowrap; text-align: right; }
  /* ປຸ່ມຈັດການ — own styles so the global theme can't shrink or recolour them */
  /* !important on colours: a global theme rule was making the green button transparent,
     so its white label floated over the neighbouring button. */
  .cdb-actions { display: inline-flex; flex-wrap: nowrap; justify-content: center; align-items: center; gap: 6px; }
  .cdb .cdb-act { position: static !important; display: inline-flex !important; align-items: center; justify-content: center; gap: 6px;
    height: auto; min-height: 34px; padding: 6px 12px; margin: 0 !important; border-radius: 8px; border: 1.5px solid transparent;
    font-family: 'Noto Sans Lao', 'Souliyo', 'Boon', sans-serif; font-size: 0.85rem; font-weight: 600; line-height: 1.6;
    white-space: nowrap; cursor: pointer; transition: background .15s, color .15s, transform .12s; opacity: 1 !important; }
  .cdb .cdb-act i { font-size: 0.9rem; line-height: 1; margin: 0 !important; }
  .cdb .cdb-act span { position: static !important; }
  /* icon-only, no box (table ຈັດການ column + details popup); the name shows as a tooltip */
  .cdb .cdb-act.cdb-act-icon { width: 30px; height: 30px; min-height: 30px; padding: 0 !important; background: transparent !important;
    border: none !important; box-shadow: none !important; border-radius: 6px; }
  .cdb .cdb-act.cdb-act-icon i { font-size: 1.15rem; }
  .cdb .cdb-act.cdb-act-icon.cdb-act-detail { color: #244886 !important; }
  .cdb .cdb-act.cdb-act-icon.cdb-act-pay { color: #16a34a !important; }
  .cdb .cdb-act.cdb-act-icon.cdb-act-cancel { color: #dc2626 !important; }
  .cdb .cdb-act.cdb-act-icon:hover { background: transparent !important; transform: scale(1.18); }
  .cdb .cdb-act.cdb-act-icon.cdb-act-detail:hover { color: #1a3666 !important; }
  .cdb .cdb-act.cdb-act-icon.cdb-act-pay:hover { color: #15803d !important; }
  .cdb .cdb-act.cdb-act-icon.cdb-act-cancel:hover { color: #b91c1c !important; }
  /* Pay modal: one row of compact buttons — ເງິນສົດ or the bank (logo + name) the transfer went into */
  .cdb-paybtns { display: flex; flex-wrap: wrap; gap: 6px; }
  .cdb .cdb-paybtn { display: inline-flex; align-items: center; gap: 6px; height: 36px; padding: 0 12px; border-radius: 8px;
    border: 1.5px solid #cbd5e1; background: #fff; color: #475569; font-weight: 600; font-size: 0.86rem; line-height: 1.5;
    font-family: 'Noto Sans Lao', 'Souliyo', 'Boon', sans-serif; cursor: pointer; white-space: nowrap; transition: all .15s; }
  .cdb .cdb-paybtn:hover { border-color: #94a3b8; }
  .cdb .cdb-paybtn img { width: 22px; height: 22px; object-fit: contain; border-radius: 5px; background: #fff; }
  .cdb .cdb-paybtn i { font-size: 0.9rem; }
  .cdb .cdb-paybtn.active { border-color: #7c3aed; background: #faf5ff; color: #6d28d9; box-shadow: 0 0 0 2px rgba(124, 58, 237, .12); }
  .cdb .cdb-paybtn-cash.active { border-color: #16a34a; background: #f0fdf4; color: #15803d; box-shadow: 0 0 0 2px rgba(22, 163, 74, .12); }
  /* bank logo + name in payment history / report */
  .cdb-paybank { display: inline-flex; align-items: center; gap: 5px; white-space: nowrap; }
  .cdb-paybank img { width: 20px; height: 20px; object-fit: contain; border-radius: 4px; border: 1px solid #e2e8f0; background: #fff; }
  .cdb-results { max-height: 260px; overflow-y: auto; border: 1px solid #e2e8f0; border-top: 0; border-radius: 0 0 8px 8px; }
  .cdb-results:empty { display: none; }
  .cdb-result { display: flex; justify-content: space-between; align-items: center; gap: 10px; padding: 8px 12px; cursor: pointer; border-top: 1px solid #f1f5f9; }
  .cdb-result:first-child { border-top: 0; }
  .cdb-result:hover, .cdb-result.active { background: #eef2fb; }
  .cdb-result mark { background: #fef08a; padding: 0; }
  .cdb-result-empty { padding: 12px; text-align: center; color: #94a3b8; font-size: 0.85rem; }
  .cdb-chosen { display: flex; justify-content: space-between; align-items: center; gap: 10px; padding: 9px 12px; border: 2px solid #16a34a; background: #f0fdf4; border-radius: 8px; }
  .cdb .min-w-0 { min-width: 0; }
  .cdb .modal-content { border-radius: 12px; border: none; }
  .cdb .modal-header { background: #244886; color: #fff; border-radius: 12px 12px 0 0; }
  /* Default theme colour for bg-primary headers. :where() keeps this at the same weight as
     Bootstrap`s .bg-primary (so it wins on source order) but below the theme picker`s
     "body .bg-primary" rule, so a chosen theme colour still takes over. */
  :where(.cdb .modal-header).bg-primary { background: #244886 !important; }
  /* Detail popup pagination — Bootstrap .pagination, so the theme picker recolours the active page */
  .cdb-modal-pager { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px; padding: 8px 2px 0; }
  .cdb-modal-pager small { color: #64748b; font-weight: 600; }
  .cdb-modal-pager .pagination { margin: 0; }
  .cdb-modal-pager .page-link { width: 32px; height: 32px; padding: 0; display: flex; align-items: center; justify-content: center; border-radius: 50% !important; margin: 0 2px; font-weight: 700; font-size: 0.85rem; border: 1px solid #e2e8f0; }
  .cdb-modal-pager .page-item.active .page-link { color: #fff; }
  .cdb .modal-header .close { color: #fff; opacity: .9; }
</style>

<div class="container-fluid p-3 p-md-4 cdb">
  <div class="d-flex justify-content-between align-items-start mb-3 flex-wrap" style="gap: 12px;">
    <div>
      <h5 class="cdb-title"><i class="fas fa-hand-holding-usd text-danger mr-1"></i> <?php echo htmlspecialchars(t('customer_debt.title', 'ລູກຄ້າຕິດໜີ້')); ?></h5>
      <div class="cdb-sub"><?php echo htmlspecialchars(t('customer_debt.subtitle', 'ໜີ້ຈາກການຂາຍຕິດໜີ້ໃນ POS ແລະ ໜີ້ຍົກມາ — ຮັບຊຳລະໄດ້ຈາກໜ້ານີ້')); ?></div>
    </div>
    <?php if ($canAddDebt): ?>
      <button type="button" class="btn btn-danger btn-sm px-3" style="border-radius: 8px; height: 36px;" onclick="openAddDebt()">
        <i class="fas fa-plus mr-1"></i> <?php echo htmlspecialchars(t('customer_debt.btn_add', 'ເພີ່ມໜີ້ຍົກມາ')); ?>
      </button>
    <?php endif; ?>
  </div>

  <div class="cdb-stats mb-3">
    <?php
      $tiles = [
        [t('customer_debt.card_outstanding', 'ໜີ້ຄ້າງທັງໝົດ'), formatCurrency($debtSummary['outstanding']), 'fa-file-invoice-dollar', '#dc2626', '#991b1b'],
        [t('customer_debt.card_customers', 'ລູກຄ້າທີ່ຕິດໜີ້'), number_format((int)$debtSummary['customers']) . ' ' . t('customer_debt.unit_people', 'ຄົນ'), 'fa-users', '#2c5aa0', '#1e3a70'],
        [t('customer_debt.card_overdue', 'ໜີ້ກາຍກຳນົດ'), formatCurrency($debtSummary['overdue']), 'fa-exclamation-triangle', '#d97706', '#b45309'],
        [t('customer_debt.card_collected_today', 'ຮັບຊຳລະມື້ນີ້'), formatCurrency($debtSummary['collected_today']), 'fa-coins', '#16a34a', '#15803d'],
      ];
      foreach ($tiles as $tile):
    ?>
      <div class="cdb-stat" style="--c: <?php echo $tile[3]; ?>; --d: <?php echo $tile[4]; ?>;">
        <div class="ico"><i class="fas <?php echo $tile[2]; ?>"></i></div>
        <div class="lbl"><?php echo htmlspecialchars($tile[0]); ?></div>
        <div class="num"><?php echo htmlspecialchars($tile[1]); ?></div>
      </div>
    <?php endforeach; ?>
  </div>

  <div class="cdb-panel">
    <form method="GET" class="cdb-filters">
      <input type="hidden" name="status" value="<?php echo htmlspecialchars($debtStatus); ?>">
      <div style="flex: 2 1 240px;">
        <label><?php echo htmlspecialchars(t('customer_debt.search_label', 'ຄົ້ນຫາ:')); ?></label>
        <input type="text" name="q" value="<?php echo htmlspecialchars($debtSearch); ?>" class="form-control" placeholder="<?php echo htmlspecialchars(t('customer_debt.search_placeholder', 'ຊື່ລູກຄ້າ, ເບີໂທ, ເລກບິນ...')); ?>">
      </div>
      <div class="d-flex" style="gap: 6px;">
        <button type="submit" class="btn btn-primary px-3" style="background: #244886; border-color: #244886;"><i class="fas fa-search mr-1"></i> <?php echo htmlspecialchars(t('customer_debt.search_btn', 'ຄົ້ນຫາ')); ?></button>
        <a href="customer_debts.php" class="btn btn-light border px-3 d-flex align-items-center"><i class="fas fa-redo text-muted"></i></a>
      </div>
      <div class="cdb-tabs ml-md-auto">
        <?php foreach ($statusTabs as $key => $label): ?>
          <a href="?<?php echo htmlspecialchars(http_build_query(['status' => $key, 'q' => $debtSearch])); ?>" class="<?php echo $debtStatus === $key ? 'active' : ''; ?>"><?php echo htmlspecialchars($label); ?></a>
        <?php endforeach; ?>
      </div>
    </form>

    <div class="table-responsive">
      <table class="table cdb-table">
        <thead>
          <tr>
            <th class="text-center" style="width: 50px;">#</th>
            <th><?php echo htmlspecialchars(t('customer_debt.col_customer', 'ລູກຄ້າ')); ?></th>
            <th class="text-center"><?php echo htmlspecialchars(t('customer_debt.col_bills', 'ບິນຄ້າງ')); ?></th>
            <th class="text-right"><?php echo htmlspecialchars(t('customer_debt.col_total', 'ຍອດໜີ້')); ?></th>
            <th class="text-right"><?php echo htmlspecialchars(t('customer_debt.col_paid', 'ຊຳລະແລ້ວ')); ?></th>
            <th class="text-right"><?php echo htmlspecialchars(t('customer_debt.col_balance', 'ຄົງເຫຼືອ')); ?></th>
            <th class="text-center"><?php echo htmlspecialchars(t('customer_debt.col_oldest', 'ຕິດໜີ້ແຕ່')); ?></th>
            <th class="text-center"><?php echo htmlspecialchars(t('customer_debt.col_actions', 'ຈັດການ')); ?></th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($debtCustomers)): ?>
            <tr><td colspan="8" class="text-center py-5 text-muted">
              <i class="fas fa-hand-holding-usd fa-2x mb-2 d-block" style="color: #cbd5e1;"></i>
              <?php echo htmlspecialchars(t('customer_debt.empty', 'ບໍ່ມີລາຍການໜີ້')); ?>
            </td></tr>
          <?php else: foreach ($debtCustomers as $i => $c): ?>
            <?php $bal = (float)$c['balance']; ?>
            <tr>
              <td class="text-center text-muted"><?php echo $i + 1; ?></td>
              <td>
                <div class="cdb-name"><?php echo htmlspecialchars($c['customer_name'] ?? '-'); ?></div>
                <div class="cdb-meta">
                  <?php echo htmlspecialchars($c['customer_code'] ?? ''); ?>
                  <?php if (!empty($c['phone'])): ?> · <i class="fas fa-phone-alt"></i> <?php echo htmlspecialchars($c['phone']); ?><?php endif; ?>
                </div>
              </td>
              <td class="text-center"><?php echo (int)$c['open_bills']; ?> / <?php echo (int)$c['bills']; ?></td>
              <td class="cdb-money"><?php echo formatCurrency($c['total_amount']); ?></td>
              <td class="cdb-money text-success"><?php echo formatCurrency($c['paid_amount']); ?></td>
              <td class="cdb-money">
                <?php if ($bal > 0): ?>
                  <span class="font-weight-bold text-danger"><?php echo formatCurrency($bal); ?></span>
                  <?php if ((float)$c['overdue'] > 0): ?><div><span class="cdb-pill warning"><?php echo htmlspecialchars(t('customer_debt.tab_overdue', 'ກາຍກຳນົດ')); ?> <?php echo formatCurrency($c['overdue']); ?></span></div><?php endif; ?>
                <?php else: ?>
                  <span class="cdb-pill success"><?php echo htmlspecialchars(t('customer_debt.status_paid', 'ຊຳລະຄົບ')); ?></span>
                <?php endif; ?>
              </td>
              <td class="text-center" style="white-space: nowrap;"><?php echo $c['oldest_open'] ? date('d/m/Y', strtotime($c['oldest_open'])) : '-'; ?></td>
              <td class="text-center" style="white-space: nowrap;">
                <div class="cdb-actions">
                  <button type="button" class="cdb-act cdb-act-icon cdb-act-detail" onclick="openDebtDetail(<?php echo (int)$c['customer_id']; ?>)" title="<?php echo htmlspecialchars(t('customer_debt.btn_detail', 'ລາຍລະອຽດ')); ?>">
                    <i class="fas fa-eye"></i>
                  </button>
                  <?php if ($canPayDebt && $bal > 0): ?>
                    <button type="button" class="cdb-act cdb-act-icon cdb-act-pay" onclick="openPayDebt(<?php echo (int)$c['customer_id']; ?>, 0, <?php echo htmlspecialchars(json_encode($c['customer_name'] ?? ''), ENT_QUOTES); ?>, '', <?php echo $bal; ?>)" title="<?php echo htmlspecialchars(t('customer_debt.btn_pay', 'ຮັບຊຳລະ')); ?>">
                      <i class="fas fa-money-bill-wave"></i>
                    </button>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Detail modal -->
  <div class="modal fade" id="debtDetailModal" tabindex="-1">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
      <div class="modal-content">
        <!-- bg-primary: follows the colour chosen in the dashboard theme picker -->
        <div class="modal-header bg-primary">
          <h5 class="modal-title font-weight-bold"><i class="fas fa-user mr-1"></i> <span id="ddCustomerName"></span></h5>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <h6 class="font-weight-bold"><?php echo htmlspecialchars(t('customer_debt.detail_bills', 'ລາຍການໜີ້')); ?></h6>
          <div class="table-responsive mb-3">
            <table class="table cdb-table">
              <thead><tr>
                <th><?php echo htmlspecialchars(t('customer_debt.col_date', 'ວັນທີ')); ?></th>
                <th><?php echo htmlspecialchars(t('customer_debt.col_invoice', 'ເລກບິນ')); ?></th>
                <th class="text-right"><?php echo htmlspecialchars(t('customer_debt.col_bill_amount', 'ຍອດບິນ')); ?></th>
                <th class="text-right"><?php echo htmlspecialchars(t('customer_debt.col_deposit', 'ມັດຈຳ')); ?></th>
                <th class="text-right"><?php echo htmlspecialchars(t('customer_debt.col_total', 'ຍອດໜີ້')); ?></th>
                <th class="text-right"><?php echo htmlspecialchars(t('customer_debt.col_paid', 'ຊຳລະແລ້ວ')); ?></th>
                <th class="text-right"><?php echo htmlspecialchars(t('customer_debt.col_balance', 'ຄົງເຫຼືອ')); ?></th>
                <th class="text-center"><?php echo htmlspecialchars(t('customer_debt.col_due', 'ກຳນົດຊຳລະ')); ?></th>
                <th class="text-center"><?php echo htmlspecialchars(t('customer_debt.col_status', 'ສະຖານະ')); ?></th>
                <th></th>
              </tr></thead>
              <tbody id="ddBills"></tbody>
            </table>
          </div>
          <div class="cdb-modal-pager mb-3" id="ddBillsPager"></div>
          <h6 class="font-weight-bold"><?php echo htmlspecialchars(t('customer_debt.detail_payments', 'ປະຫວັດການຊຳລະ')); ?></h6>
          <div class="table-responsive">
            <table class="table cdb-table">
              <thead><tr>
                <th><?php echo htmlspecialchars(t('customer_debt.col_date', 'ວັນທີ')); ?></th>
                <th><?php echo htmlspecialchars(t('customer_debt.col_invoice', 'ເລກບິນ')); ?></th>
                <th class="text-right"><?php echo htmlspecialchars(t('customer_debt.col_amount', 'ຈຳນວນເງິນ')); ?></th>
                <th><?php echo htmlspecialchars(t('customer_debt.col_method', 'ຊ່ອງທາງ')); ?></th>
                <th><?php echo htmlspecialchars(t('customer_debt.col_note', 'ໝາຍເຫດ')); ?></th>
                <th><?php echo htmlspecialchars(t('customer_debt.col_received_by', 'ຜູ້ຮັບ')); ?></th>
              </tr></thead>
              <tbody id="ddPayments"></tbody>
            </table>
          </div>
          <div class="cdb-modal-pager" id="ddPaymentsPager"></div>
        </div>
      </div>
    </div>
  </div>

  <!-- Pay modal -->
  <div class="modal fade" id="payDebtModal" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header" style="background: #16a34a;">
          <h5 class="modal-title font-weight-bold"><i class="fas fa-money-bill-wave mr-1"></i> <?php echo htmlspecialchars(t('customer_debt.pay_title', 'ຮັບຊຳລະໜີ້')); ?></h5>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <input type="hidden" id="payCustomerId"><input type="hidden" id="payDebtId">
          <div class="mb-2"><span class="text-muted"><?php echo htmlspecialchars(t('customer_debt.col_customer', 'ລູກຄ້າ')); ?>:</span> <b id="payCustomerName"></b> <span id="payInvoiceLbl" class="text-muted"></span></div>
          <div class="p-2 mb-3 rounded" style="background: #fef2f2;">
            <span class="text-muted"><?php echo htmlspecialchars(t('customer_debt.pay_outstanding', 'ຍອດຄ້າງຊຳລະ')); ?>:</span>
            <b class="text-danger" id="payOutstanding" style="font-size: 1.15rem;"></b>
          </div>
          <div class="form-group">
            <label class="font-weight-bold"><?php echo htmlspecialchars(t('customer_debt.col_amount', 'ຈຳນວນເງິນ')); ?> <span class="text-danger">*</span></label>
            <div class="input-group">
              <input type="text" id="payAmount" class="form-control text-right font-weight-bold" style="font-size: 1.15rem;" inputmode="numeric" placeholder="<?php echo htmlspecialchars(t('customer_debt.amount_placeholder', 'ປ້ອນຈຳນວນເງິນ ເຊັ່ນ: 100,000')); ?>" oninput="cdbFormatMoney(this)">
              <div class="input-group-append"><button type="button" class="btn btn-outline-success" onclick="$('#payAmount').val(cdbNum(window.__payOutstanding))"><?php echo htmlspecialchars(t('customer_debt.pay_full', 'ຊຳລະທັງໝົດ')); ?></button></div>
            </div>
            <small class="text-muted" id="payFifoHint"><?php echo htmlspecialchars(t('customer_debt.pay_fifo_hint', 'ເງິນຈະຖືກຫັກຈາກບິນເກົ່າສຸດກ່ອນ')); ?></small>
          </div>
          <div class="form-group">
            <label class="font-weight-bold"><?php echo htmlspecialchars(t('customer_debt.col_method', 'ຊ່ອງທາງ')); ?> <span class="text-danger">*</span></label>
            <input type="hidden" id="payMethod" value="cash">
            <input type="hidden" id="payBank" value="">
            <!-- One click picks everything: ເງິນສົດ, or the bank the transfer went into -->
            <div class="cdb-paybtns">
              <button type="button" class="cdb-paybtn cdb-paybtn-cash active" data-pay="cash" onclick="pickPay('cash')">
                <i class="fas fa-money-bill-wave"></i><span><?php echo htmlspecialchars(t('customer_debt.method_cash', 'ເງິນສົດ')); ?></span>
              </button>
              <?php foreach ($debtBanks as $b): ?>
                <button type="button" class="cdb-paybtn" data-pay="bank" data-bank="<?php echo $b['id']; ?>" onclick="pickPay('bank', <?php echo $b['id']; ?>)"
                        title="<?php echo htmlspecialchars(trim($b['bank_name'] . ' · ' . $b['account_number'] . ($b['account_name'] !== '' ? ' · ' . $b['account_name'] : ''), ' ·')); ?>">
                  <?php if (!empty($b['logo'])): ?>
                    <img src="<?php echo htmlspecialchars($b['logo']); ?>" alt="" onerror="this.replaceWith(Object.assign(document.createElement('i'), {className: 'fas fa-university'}))">
                  <?php else: ?>
                    <i class="fas fa-university"></i>
                  <?php endif; ?>
                  <span><?php echo htmlspecialchars($b['bank_name']); ?></span>
                </button>
              <?php endforeach; ?>
              <?php if (empty($debtBanks)): ?>
                <button type="button" class="cdb-paybtn" data-pay="transfer" onclick="pickPay('transfer')">
                  <i class="fas fa-university"></i><span><?php echo htmlspecialchars(t('customer_debt.method_transfer', 'ໂອນເງິນ / QR')); ?></span>
                </button>
              <?php endif; ?>
            </div>
          </div>
          <div class="form-group mb-0">
            <label class="font-weight-bold"><?php echo htmlspecialchars(t('customer_debt.col_note', 'ໝາຍເຫດ')); ?></label>
            <input type="text" id="payNote" class="form-control" maxlength="255" placeholder="<?php echo htmlspecialchars(t('customer_debt.pay_note_placeholder', 'ເຊັ່ນ: ໂອນຈາກບັນຊີລູກຄ້າ, ເລກອ້າງອີງການໂອນ...')); ?>">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-light border" data-dismiss="modal"><?php echo htmlspecialchars(t('customer_debt.btn_cancel', 'ຍົກເລີກ')); ?></button>
          <button type="button" class="btn btn-success font-weight-bold" id="btnSubmitPay" onclick="submitPayDebt()"><i class="fas fa-check mr-1"></i> <?php echo htmlspecialchars(t('customer_debt.btn_confirm_pay', 'ຢືນຢັນຮັບເງິນ')); ?></button>
        </div>
      </div>
    </div>
  </div>

  <?php if ($canAddDebt): ?>
  <!-- Add opening balance modal -->
  <div class="modal fade" id="addDebtModal" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header" style="background: #dc2626;">
          <h5 class="modal-title font-weight-bold"><i class="fas fa-plus mr-1"></i> <?php echo htmlspecialchars(t('customer_debt.btn_add', 'ເພີ່ມໜີ້ຍົກມາ')); ?></h5>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label class="font-weight-bold"><?php echo htmlspecialchars(t('customer_debt.col_customer', 'ລູກຄ້າ')); ?> <span class="text-danger">*</span></label>
            <input type="hidden" id="addCustomer" value="">
            <!-- Picked customer -->
            <div id="addCustomerChosen" class="cdb-chosen" style="display: none;">
              <div class="min-w-0">
                <div class="font-weight-bold text-truncate" id="addCustomerChosenName"></div>
                <div class="cdb-meta text-truncate" id="addCustomerChosenMeta"></div>
              </div>
              <button type="button" class="btn btn-sm btn-light border flex-shrink-0" onclick="clearPickedCustomer()">
                <i class="fas fa-exchange-alt mr-1"></i><?php echo htmlspecialchars(t('customer_debt.change_customer', 'ປ່ຽນ')); ?>
              </button>
            </div>
            <!-- Live search -->
            <div id="addCustomerSearchWrap">
              <div class="input-group">
                <div class="input-group-prepend"><span class="input-group-text bg-white"><i class="fas fa-search text-muted"></i></span></div>
                <input type="text" id="addCustomerSearch" class="form-control" autocomplete="off"
                       placeholder="<?php echo htmlspecialchars(t('customer_debt.customer_search_placeholder', 'ພິມຊື່, ເບີໂທ ຫຼື ລະຫັດລູກຄ້າ...')); ?>">
              </div>
              <div id="addCustomerResults" class="cdb-results"></div>
            </div>
          </div>
          <div class="form-group">
            <label class="font-weight-bold"><?php echo htmlspecialchars(t('customer_debt.col_amount', 'ຈຳນວນເງິນ')); ?> <span class="text-danger">*</span></label>
            <input type="text" id="addAmount" class="form-control text-right font-weight-bold" inputmode="numeric" placeholder="<?php echo htmlspecialchars(t('customer_debt.amount_placeholder', 'ປ້ອນຈຳນວນເງິນ ເຊັ່ນ: 100,000')); ?>" oninput="cdbFormatMoney(this)">
          </div>
          <div class="form-group">
            <label class="font-weight-bold"><?php echo htmlspecialchars(t('customer_debt.col_due', 'ກຳນົດຊຳລະ')); ?></label>
            <input type="date" id="addDueDate" class="form-control">
          </div>
          <div class="form-group mb-0">
            <label class="font-weight-bold"><?php echo htmlspecialchars(t('customer_debt.col_note', 'ໝາຍເຫດ')); ?></label>
            <input type="text" id="addNote" class="form-control" maxlength="255" placeholder="<?php echo htmlspecialchars(t('customer_debt.add_note_placeholder', 'ເຊັ່ນ: ໜີ້ຍົກມາຈາກປຶ້ມບັນຊີເກົ່າ')); ?>">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-light border" data-dismiss="modal"><?php echo htmlspecialchars(t('customer_debt.btn_cancel', 'ຍົກເລີກ')); ?></button>
          <button type="button" class="btn btn-danger font-weight-bold" onclick="submitAddDebt()"><i class="fas fa-save mr-1"></i> <?php echo htmlspecialchars(t('customer_debt.btn_save', 'ບັນທຶກ')); ?></button>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>
</div>

<script>
var CDB_URL = '../../api/customer_debts_backend.php';
var CDB_CAN_PAY = <?php echo $canPayDebt ? 'true' : 'false'; ?>;
var CDB_CAN_CANCEL = <?php echo $canCancelDebt ? 'true' : 'false'; ?>;
var CDB_I18N = <?php echo json_encode([
  'unpaid'      => t('customer_debt.status_unpaid', 'ຍັງບໍ່ຊຳລະ'),
  'partial'     => t('customer_debt.status_partial', 'ຊຳລະບາງສ່ວນ'),
  'paid'        => t('customer_debt.status_paid', 'ຊຳລະຄົບ'),
  'cancelled'   => t('customer_debt.status_cancelled', 'ຍົກເລີກ'),
  'overdue'     => t('customer_debt.tab_overdue', 'ກາຍກຳນົດ'),
  'opening'     => t('customer_debt.opening_balance', 'ໜີ້ຍົກມາ'),
  'pay'         => t('customer_debt.btn_pay', 'ຮັບຊຳລະ'),
  'cancel'      => t('customer_debt.btn_cancel_debt', 'ຍົກເລີກໜີ້'),
  'no_payments' => t('customer_debt.no_payments', 'ຍັງບໍ່ມີການຊຳລະ'),
  'confirm_cancel' => t('customer_debt.confirm_cancel', 'ຢືນຢັນຍົກເລີກໜີ້ນີ້?'),
  'yes'         => t('customer_debt.yes', 'ຕົກລົງ'),
  'no'          => t('customer_debt.btn_cancel', 'ຍົກເລີກ'),
  'error'       => t('customer_debt.error_title', 'ຜິດພາດ'),
  'no_customer' => t('customer_debt.no_customer_found', 'ບໍ່ພົບລູກຄ້າ'),
  'no_debts'    => t('customer_debt.empty', 'ບໍ່ມີລາຍການໜີ້'),
  'pager'       => t('debt_report.pager_showing', 'ສະແດງ %s–%s ຈາກ %s ລາຍການ'),
  'owes'        => t('customer_debt.owes', 'ຄ້າງ'),
], JSON_UNESCAPED_UNICODE); ?>;
var __ddCustomerId = 0;

function cdbNum(n) { return Math.round(parseFloat(n) || 0).toLocaleString('en-US'); }
function cdbMoney(n) { return cdbNum(n) + ' ₭'; }
function cdbEsc(s) { return $('<div>').text(s == null ? '' : String(s)).html(); }
function cdbDate(s) { if (!s) return '-'; var d = String(s).substr(0, 10).split('-'); return d[2] + '/' + d[1] + '/' + d[0] + (String(s).length > 10 ? ' ' + String(s).substr(11, 5) : ''); }
function cdbFormatMoney(el) { var v = el.value.replace(/[^0-9]/g, ''); el.value = v ? parseInt(v, 10).toLocaleString('en-US') : ''; }
function cdbToast(res) {
  Swal.fire({ icon: res.success ? 'success' : 'error', title: res.success ? res.message : CDB_I18N.error, text: res.success ? '' : res.message });
}

function openDebtDetail(customerId) {
  __ddCustomerId = customerId;
  $.post(CDB_URL, { action: 'debt_detail', customer_id: customerId }, function (res) {
    if (!res.success) return cdbToast(res);
    var today = new Date().toISOString().substr(0, 10);
    var name = res.debts.length ? res.debts[0].customer_name : '';
    $('#ddCustomerName').text(name);
    window.__ddDebts = {};
    res.debts.forEach(function (d) { window.__ddDebts[d.id] = d; });
    var rows = res.debts.map(function (d) {
      var open = d.status === 'unpaid' || d.status === 'partial';
      var pillCls = { unpaid: 'danger', partial: 'warning', paid: 'success', cancelled: 'muted' }[d.status] || 'muted';
      var overdue = open && d.due_date && d.due_date < today;
      var actions = '';
      if (open && CDB_CAN_PAY) {
        actions += '<button type="button" class="cdb-act cdb-act-icon cdb-act-pay" title="' + CDB_I18N.pay + '" onclick="openPayDebtBill(' + d.id + ')"><i class="fas fa-money-bill-wave"></i></button>';
      }
      if (CDB_CAN_CANCEL && !d.invoice_number && d.status === 'unpaid') {
        actions += '<button type="button" class="cdb-act cdb-act-icon cdb-act-cancel" title="' + CDB_I18N.cancel + '" onclick="cancelDebt(' + d.id + ')"><i class="fas fa-ban"></i></button>';
      }
      if (actions) actions = '<div class="cdb-actions">' + actions + '</div>';
      return '<tr' + (d.status === 'cancelled' ? ' style="opacity:.55"' : '') + '>' +
        '<td style="white-space:nowrap">' + cdbDate(d.created_at) + '</td>' +
        '<td>' + (d.invoice_number ? cdbEsc(d.invoice_number) : '<span class="cdb-pill muted">' + CDB_I18N.opening + '</span>') +
          (d.note ? '<div class="cdb-meta">' + cdbEsc(d.note) + '</div>' : '') + '</td>' +
        '<td class="cdb-money">' + cdbMoney(d.bill_amount) + '</td>' +
        '<td class="cdb-money">' + cdbMoney(d.deposit_amount) + '</td>' +
        '<td class="cdb-money">' + cdbMoney(d.amount) + '</td>' +
        '<td class="cdb-money text-success">' + cdbMoney(d.paid_amount) + '</td>' +
        '<td class="cdb-money font-weight-bold ' + (open ? 'text-danger' : '') + '">' + cdbMoney(d.balance) + '</td>' +
        '<td class="text-center" style="white-space:nowrap">' + (d.due_date ? cdbDate(d.due_date) : '-') +
          (overdue ? '<div><span class="cdb-pill warning">' + CDB_I18N.overdue + '</span></div>' : '') + '</td>' +
        '<td class="text-center"><span class="cdb-pill ' + pillCls + '">' + (CDB_I18N[d.status] || d.status) + '</span></td>' +
        '<td class="text-right" style="white-space:nowrap">' + actions + '</td></tr>';
    });
    cdbPagedTable('ddBills', rows, 10, CDB_I18N.no_debts);
    var pays = res.payments.map(function (p) {
      return '<tr><td style="white-space:nowrap">' + cdbDate(p.paid_at) + '</td>' +
        '<td>' + (p.invoice_number ? cdbEsc(p.invoice_number) : '<span class="cdb-pill muted">' + CDB_I18N.opening + '</span>') + '</td>' +
        '<td class="cdb-money font-weight-bold text-success">' + cdbMoney(p.amount) + '</td>' +
        '<td>' + cdbPayMethodHtml(p) + '</td>' +
        '<td>' + cdbEsc(p.note || '') + '</td><td>' + cdbEsc(p.received_by || '') + '</td></tr>';
    });
    cdbPagedTable('ddPayments', pays, 6, CDB_I18N.no_payments);
    $('#debtDetailModal').modal('show');
  }, 'json');
}

// Client-side pages for the detail popup tables: 5 rows a page, and the page buttons are
// always shown (even with a single page) under "ສະແດງ a–b ຈາກ n".
var CDB_DD_PER_PAGE = 5;
var __cdbPaged = {};
function cdbPagedTable(tbodyId, rowsHtml, colspan, emptyText) {
  __cdbPaged[tbodyId] = { rows: rowsHtml, colspan: colspan, empty: emptyText };
  cdbRenderPage(tbodyId, 1);
}
function cdbRenderPage(tbodyId, page) {
  var st = __cdbPaged[tbodyId];
  if (!st) return;
  var total = st.rows.length;
  var pages = Math.max(1, Math.ceil(total / CDB_DD_PER_PAGE));
  page = Math.min(Math.max(1, page), pages);
  var from = (page - 1) * CDB_DD_PER_PAGE;
  $('#' + tbodyId).html(total
    ? st.rows.slice(from, from + CDB_DD_PER_PAGE).join('')
    : '<tr><td colspan="' + st.colspan + '" class="text-center text-muted py-3">' + st.empty + '</td></tr>');

  var li = function (p, label, cls) {
    return '<li class="page-item ' + (cls || '') + '"><a class="page-link" href="javascript:void(0)" data-tbody="' + tbodyId + '" data-page="' + p + '">' + label + '</a></li>';
  };
  var html = li(page - 1, '<i class="fas fa-chevron-left" style="font-size:0.7rem"></i>', page <= 1 ? 'disabled' : '');
  var start = Math.max(1, page - 2), end = Math.min(pages, page + 2);
  if (start > 1) html += li(1, '1') + (start > 2 ? '<li class="page-item disabled"><span class="page-link" style="border:none">…</span></li>' : '');
  for (var p = start; p <= end; p++) html += li(p, p, p === page ? 'active' : '');
  if (end < pages) html += (end < pages - 1 ? '<li class="page-item disabled"><span class="page-link" style="border:none">…</span></li>' : '') + li(pages, pages);
  html += li(page + 1, '<i class="fas fa-chevron-right" style="font-size:0.7rem"></i>', page >= pages ? 'disabled' : '');

  var showing = CDB_I18N.pager.replace('%s', total ? from + 1 : 0).replace('%s', Math.min(from + CDB_DD_PER_PAGE, total)).replace('%s', total);
  $('#' + tbodyId + 'Pager').html('<small>' + showing + '</small><ul class="pagination">' + html + '</ul>');
}
$(document).on('click', '.cdb-modal-pager .page-link[data-page]', function () {
  if ($(this).parent().hasClass('disabled') || $(this).parent().hasClass('active')) return;
  cdbRenderPage($(this).data('tbody'), parseInt($(this).data('page'), 10));
});

// Payment history "ຊ່ອງທາງ": 💵 ເງິນສົດ, or the receiving bank's logo + name (+ account no.)
function cdbPayMethodHtml(p) {
  if (!p.bank_name && p.payment_method === 'ເງິນສົດ') {
    return '<span class="cdb-paybank text-success"><i class="fas fa-money-bill-wave"></i>' + cdbEsc(p.payment_method) + '</span>';
  }
  var logo = p.bank_logo_url
    ? '<img src="' + cdbEsc(p.bank_logo_url) + '" alt="" onerror="this.style.display=\'none\'">'
    : '<i class="fas fa-university text-primary"></i>';
  var label = p.bank_name ? cdbEsc(p.bank_name) : cdbEsc(p.payment_method);
  var acc = p.bank_account_no ? '<div class="cdb-meta">' + cdbEsc(p.bank_account_no) + '</div>' : '';
  return '<span class="cdb-paybank">' + logo + '<b>' + label + '</b></span>' + acc;
}

function openPayDebt(customerId, debtId, name, invoice, outstanding) {
  window.__payOutstanding = outstanding;
  $('#payCustomerId').val(customerId);
  $('#payDebtId').val(debtId || 0);
  $('#payCustomerName').text(name || '');
  $('#payInvoiceLbl').text(invoice ? '— ' + invoice : '');
  $('#payOutstanding').text(cdbMoney(outstanding));
  $('#payAmount').val(cdbNum(outstanding));
  $('#payFifoHint').toggle(!debtId);
  pickPay('cash'); $('#payNote').val('');
  $('#payDebtModal').modal('show');
  setTimeout(function () { $('#payAmount').focus().select(); }, 400);
}

function openPayDebtBill(debtId) {
  var d = (window.__ddDebts || {})[debtId];
  if (!d) return;
  $('#debtDetailModal').modal('hide');
  openPayDebt(d.customer_id, d.id, d.customer_name, d.invoice_number || '', parseFloat(d.balance));
}

// One click: 'cash', 'bank' + the bank account it went into, or plain 'transfer' (no banks set up).
function pickPay(kind, bankId) {
  $('#payMethod').val(kind === 'cash' ? 'cash' : 'transfer');
  $('#payBank').val(kind === 'bank' ? bankId : '');
  var $btns = $('.cdb-paybtn').removeClass('active');
  if (kind === 'bank') $btns.filter('[data-bank="' + bankId + '"]').addClass('active');
  else $btns.filter('[data-pay="' + kind + '"]').addClass('active');
}

function submitPayDebt() {
  var btn = $('#btnSubmitPay');
  if (btn.prop('disabled')) return;
  btn.prop('disabled', true);
  $.post(CDB_URL, {
    action: 'pay_debt',
    customer_id: $('#payCustomerId').val(),
    debt_id: $('#payDebtId').val(),
    amount: $('#payAmount').val().replace(/,/g, ''),
    payment_method: $('#payMethod').val(),
    bank_account_id: $('#payMethod').val() === 'transfer' ? $('#payBank').val() : '',
    note: $('#payNote').val()
  }, function (res) {
    cdbToast(res);
    if (res.success) { $('#payDebtModal').modal('hide'); setTimeout(function () { location.reload(); }, 1200); }
  }, 'json').always(function () { btn.prop('disabled', false); });
}

function cancelDebt(debtId) {
  Swal.fire({ icon: 'warning', title: CDB_I18N.confirm_cancel, showCancelButton: true, confirmButtonColor: '#dc2626', confirmButtonText: CDB_I18N.yes, cancelButtonText: CDB_I18N.no })
    .then(function (r) {
      if (!r.isConfirmed) return;
      $.post(CDB_URL, { action: 'cancel_debt', debt_id: debtId }, function (res) {
        cdbToast(res);
        if (res.success) setTimeout(function () { location.reload(); }, 1200);
      }, 'json');
    });
}

function openAddDebt() {
  clearPickedCustomer(true);
  $('#addAmount').val(''); $('#addDueDate').val(''); $('#addNote').val('');
  $('#addDebtModal').modal('show');
}

// ---- Customer picker: type a name / phone / code, pick with click or ↑ ↓ Enter ----
var __custSearchTimer = null, __custSearchSeq = 0, __custResults = [];

function cdbHighlight(text, q) {
  var safe = cdbEsc(text || '');
  if (!q) return safe;
  var i = String(text || '').toLowerCase().indexOf(q.toLowerCase());
  if (i < 0) return safe;
  return cdbEsc(text.substr(0, i)) + '<mark>' + cdbEsc(text.substr(i, q.length)) + '</mark>' + cdbEsc(text.substr(i + q.length));
}

function searchCustomers() {
  var q = $.trim($('#addCustomerSearch').val());
  var seq = ++__custSearchSeq;
  $.post(CDB_URL, { action: 'search_customers', q: q }, function (res) {
    if (seq !== __custSearchSeq || !res.success) return; // a newer keystroke already searched
    __custResults = res.customers;
    if (!__custResults.length) {
      $('#addCustomerResults').html('<div class="cdb-result-empty">' + CDB_I18N.no_customer + '</div>');
      return;
    }
    $('#addCustomerResults').html(__custResults.map(function (c, i) {
      var meta = [c.phone ? '<i class="fas fa-phone-alt"></i> ' + cdbHighlight(c.phone, q) : '', c.customer_code ? cdbHighlight(c.customer_code, q) : '']
        .filter(Boolean).join(' · ');
      var bal = parseFloat(c.balance) > 0 ? '<span class="cdb-pill danger">' + CDB_I18N.owes + ' ' + cdbMoney(c.balance) + '</span>' : '';
      return '<div class="cdb-result' + (i === 0 ? ' active' : '') + '" data-i="' + i + '">' +
        '<div class="min-w-0"><div class="font-weight-bold text-truncate">' + cdbHighlight(c.customer_name, q) + '</div>' +
        '<div class="cdb-meta text-truncate">' + meta + '</div></div>' + bal + '</div>';
    }).join(''));
  }, 'json');
}

function pickCustomer(i) {
  var c = __custResults[i];
  if (!c) return;
  $('#addCustomer').val(c.customer_id);
  $('#addCustomerChosenName').text(c.customer_name);
  $('#addCustomerChosenMeta').text([c.phone, c.customer_code].filter(Boolean).join(' · ') +
    (parseFloat(c.balance) > 0 ? '  —  ' + CDB_I18N.owes + ' ' + cdbMoney(c.balance) : ''));
  $('#addCustomerSearchWrap').hide();
  $('#addCustomerChosen').css('display', 'flex');
  setTimeout(function () { $('#addAmount').focus(); }, 50);
}

function clearPickedCustomer(silent) {
  $('#addCustomer').val('');
  $('#addCustomerChosen').hide();
  $('#addCustomerSearchWrap').show();
  $('#addCustomerSearch').val('');
  $('#addCustomerResults').empty();
  __custResults = [];
  if (!silent) { searchCustomers(); $('#addCustomerSearch').focus(); }
}

function submitAddDebt() {
  $.post(CDB_URL, {
    action: 'add_debt',
    customer_id: $('#addCustomer').val(),
    amount: $('#addAmount').val().replace(/,/g, ''),
    due_date: $('#addDueDate').val(),
    note: $('#addNote').val()
  }, function (res) {
    cdbToast(res);
    if (res.success) { $('#addDebtModal').modal('hide'); setTimeout(function () { location.reload(); }, 1200); }
  }, 'json');
}

$(function () {
  $('#addDebtModal').on('shown.bs.modal', function () {
    if (!$('#addCustomer').val()) { searchCustomers(); $('#addCustomerSearch').focus(); }
  });
  $('#addCustomerSearch').on('input', function () {
    clearTimeout(__custSearchTimer);
    __custSearchTimer = setTimeout(searchCustomers, 200);
  }).on('keydown', function (e) {
    var items = $('#addCustomerResults .cdb-result');
    if (!items.length) return;
    var cur = items.index(items.filter('.active'));
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      var next = Math.max(0, Math.min(items.length - 1, cur + (e.key === 'ArrowDown' ? 1 : -1)));
      items.removeClass('active').eq(next).addClass('active')[0].scrollIntoView({ block: 'nearest' });
    } else if (e.key === 'Enter') {
      e.preventDefault();
      pickCustomer(cur < 0 ? 0 : cur);
    }
  });
  $('#addCustomerResults').on('click', '.cdb-result', function () { pickCustomer($(this).data('i')); });
});
</script>

<?php require_once __DIR__ . '/../../layouts/footer.php'; ?>
